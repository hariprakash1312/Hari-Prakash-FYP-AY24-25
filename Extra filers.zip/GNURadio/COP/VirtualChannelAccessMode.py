from enum import Enum

# Enumerate virtual channel access modes
class VirtualChannelAccessMode(Enum):
    PACKET=0
    BITSTREAM=1
    DATA=2
    ENCAPSULATION=3