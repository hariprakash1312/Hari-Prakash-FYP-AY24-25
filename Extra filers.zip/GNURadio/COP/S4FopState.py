from overall_FopAlertCode import FopAlertCode
from overall_FopState import FopState
from overall_AbstractFopState import AbstractFopState
from overall_FopEvent import FopEvent
from overall_S6FopState import S6FopState
from overall_S1FopState import S1FopState

# Define the actions required and the appropriate methods to call for FOP-1 events while in FOP-1 state S4
class S4FopState(AbstractFopState):
    def __init__(self, engine):
        super().__init__(engine)

    # Registering event handlers for different FOP events
    def register_handlers(self):
        self.event2handler = {
            FopEvent.EventNumber.E1: self.e1,
            FopEvent.EventNumber.E3: self.e3e15,
            FopEvent.EventNumber.E4: self.e4,
            FopEvent.EventNumber.E13: self.e13,
            FopEvent.EventNumber.E14: self.e14,
            FopEvent.EventNumber.E15: self.e3e15,
            FopEvent.EventNumber.E16: self.e16e17,
            FopEvent.EventNumber.E104: self.e104e18,
            FopEvent.EventNumber.E17: self.e16e17,
            FopEvent.EventNumber.E18: self.e104e18,
            FopEvent.EventNumber.E19: self.reject,
            FopEvent.EventNumber.E20: self.reject,
            FopEvent.EventNumber.E21: self.e21,
            FopEvent.EventNumber.E22: self.reject,
            FopEvent.EventNumber.E23: self.reject,
            FopEvent.EventNumber.E24: self.reject,
            FopEvent.EventNumber.E25: self.reject,
            FopEvent.EventNumber.E26: self.reject,
            FopEvent.EventNumber.E27: self.reject,
            FopEvent.EventNumber.E28: self.reject,
            FopEvent.EventNumber.E29: self.e29,
            FopEvent.EventNumber.E30: self.reject,
            FopEvent.EventNumber.E35: self.reject,
            FopEvent.EventNumber.E36: self.e36,
            FopEvent.EventNumber.E37: self.e37,
            FopEvent.EventNumber.E38: self.e38,
            FopEvent.EventNumber.E39: self.e39,
            FopEvent.EventNumber.E40: self.reject,
            FopEvent.EventNumber.E41: self.e41,
            FopEvent.EventNumber.E42: self.e42,
            FopEvent.EventNumber.E43: self.e43,
            FopEvent.EventNumber.E44: self.e44,
            FopEvent.EventNumber.E45: self.e45,
            FopEvent.EventNumber.E46: self.e46
        }

    # Return the current state
    def get_state(self):
        return FopState.S4
    
    # Handler functions for different events
    def e1(self, fop_event):
        self.engine.confirm_pending_init_ad_with_clcw(fop_event.get_clcw())
        self.engine.cancel_timer()
        return S1FopState(self.engine)

    def e3e15(self, fop_event):
        self.engine.alert(FopAlertCode.CLCW)
        return S6FopState(self.engine)

    def e4(self, fop_event):
        self.engine.alert(FopAlertCode.SYNCH)
        return S6FopState(self.engine)

    def e13(self, fop_event):
        self.engine.alert(FopAlertCode.NN_R)
        return S6FopState(self.engine)

    def e14(self, fop_event):
        self.engine.alert(FopAlertCode.LOCKOUT)
        return S6FopState(self.engine)

    def e16e17(self, fop_event):
        self.engine.alert(FopAlertCode.T1)
        return S6FopState(self.engine)

    def e104e18(self, fop_event):
        self.engine.set_suspend_state(4)
        self.engine.suspend()
        return S6FopState(self.engine)

    def e41(self, fop_event):
        self.engine.set_ad_out_ready_flag(True)
        return self

    def e43(self, fop_event):
        self.engine.set_bc_out_ready_flag(True)
        return self

