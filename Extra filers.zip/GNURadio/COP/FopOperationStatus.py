from enum import Enum

# Enumerate Fop response types
class FopOperationStatus(Enum):
    ACCEPT_RESPONSE = 1
    REJECT_RESPONSE = 2
    POSITIVE_CONFIRM = 3
    NEGATIVE_CONFIRM = 4
