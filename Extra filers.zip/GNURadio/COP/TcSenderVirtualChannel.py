from typing import List, Callable, Optional
from overall_TcTransferFrameBuilder import TcTransferFrameBuilder
from overall_TcTransferFrame import TcTransferFrame
from overall_TransferFrameCollector import TransferFrameCollector
from overall_VirtualChannelAccessMode import VirtualChannelAccessMode
import threading
import multiprocessing

# Multi-thread increment, decrement, get value of a shared integer
class AtomicLong:
    def __init__(self, value=0):
        self._value = value
        self._lock = threading.Lock()

    def increment_and_get(self):
        with self._lock:
            self._value += 1
            return self._value

    def decrement_and_get(self):
        with self._lock:
            self._value -= 1
            return self._value

    def get(self):
        with self._lock:
            return self._value

# TC Virtual Channel that store related parameters eg frame sequence number and define methods to create AD/BD/BC frames 
# using TcTransferFrameBuilder and store them in BcFrameCollector/ TransferFrameCollector
class TcSenderVirtualChannel():
    def __init__(
        self,
        spacecraft_id: int,
        virtual_channel_id: int,
        mode: VirtualChannelAccessMode,
        fecf_present: bool,
        segmented: bool,
        sec_header_length: int = 0,
        sec_trailer_length: int = 0,
        sec_header_supplier: Optional[Callable[[], bytes]] = None,
        sec_trailer_supplier: Optional[Callable[[], bytes]] = None,
    ):
        self.listeners: List[TransferFrameCollector] = [] # List of TransferFrameCollectors storing Tc transfer frames to be sent
        self.spacecraft_id = spacecraft_id
        self.virtual_channel_id = virtual_channel_id
        self.mode = mode
        self.fecf_present = fecf_present
        self.virtual_channel_frame_counter = multiprocessing.Value('i', 0) 

        self.emitted_frames = AtomicLong(0)
        self.segmented = segmented
        self.map_id = None

        if mode == VirtualChannelAccessMode.BITSTREAM:
            raise ValueError(
                f"Virtual channel {virtual_channel_id} does not support access mode {mode}"
            )
        self.sec_header_supplier = sec_header_supplier
        self.sec_trailer_supplier = sec_trailer_supplier
        self.sec_header_length = max(sec_header_length, 0)
        self.sec_trailer_length = max(sec_trailer_length, 0)
        if sec_header_length > 0 and sec_header_supplier is None:
            raise ValueError(
                "Security header length specified, but no security header supplier provided"
            )
        if sec_trailer_length > 0 and sec_trailer_supplier is None:
            raise ValueError(
                "Security trailer length specified, but no security trailer supplier provided"
            )

    # Return whether security is used
    def is_secured(self) -> bool:
        return self.sec_header_length > 0 or self.sec_trailer_length > 0

    # Return whether segmentation is enabled
    def is_segmented(self) -> bool:
        return self.segmented

    # Return map id
    def get_map_id(self) -> int:
        return self.map_id

    # Set map id
    def set_map_id(self, map_id: int) -> None:
        self.map_id = map_id

    # Return whether it is ad transmission
    def is_ad_mode(self) -> bool:
        return self.ad_mode

    # Set whether it is ad transmission
    def set_ad_mode(self, ad_mode: bool) -> None:
        self.ad_mode = ad_mode

    # Build a BC unlock frame and save in BcFrameCollector
    def dispatch_unlock(self,req_tag: int) -> None:
        builder = TcTransferFrameBuilder(self.is_fecf_present())
        tc = (
            builder
            .set_spacecraft_id(self.get_spacecraft_id())
            .set_virtual_channel_id(self.get_virtual_channel_id())
            .set_frame_sequence_number(0)
            .set_bypass_flag(True)
            .set_control_command_flag(True)
            .set_unlock_control_command()
            .set_req_tag(req_tag)
            .build()
        )
        self.notify_transfer_frame_generated(tc, 0)

    # Build a BC set v(r) frame and save in BcFrameCollector
    def dispatch_set_vr(self, frame_number: int, req_tag: int) -> None:
        builder = TcTransferFrameBuilder(self.is_fecf_present())
        tc = (
            builder
            .set_spacecraft_id(self.get_spacecraft_id())
            .set_virtual_channel_id(self.get_virtual_channel_id())
            .set_frame_sequence_number(0)
            .set_bypass_flag(True)
            .set_control_command_flag(True)
            .set_set_vr_control_command(frame_number)
            .set_req_tag(req_tag)
            .build()
        )
        self.notify_transfer_frame_generated(tc, 0)

    # Build tc transfer frames from byte data (tc packet/segment)
    def dispatch_data(self, user_data, req_tag, operation_tag):
        return self.dispatch_data_internal(self.is_ad_mode(), self.get_map_id(), user_data, req_tag, operation_tag)

    # Build tc transfer frames from byte data (tc packet/segment) internal function
    def dispatch_data_internal(self, ad_mode, map_id, data, req_tag, operation_tag, is_packet):
        if self.get_mode() != VirtualChannelAccessMode.DATA:
            raise RuntimeError("Virtual channel {} access mode set to mode {}, but requested User Data access".format(self.get_virtual_channel_id(), self.get_mode()))

        max_data_per_frame = self.get_max_user_data_length()
        # if data length is small enough (no need segmentation), build a tc transfer frame and store in TransferFrameCollector
        if max_data_per_frame >= len(data):
            sec_header = self.sec_header_supplier() if self.sec_header_supplier else b''
            sec_trailer = self.sec_trailer_supplier() if self.sec_trailer_supplier else b''
            builder = TcTransferFrameBuilder(self.is_fecf_present())
            # Set transfer frame header variables
            current_frame =  builder \
                .set_spacecraft_id(self.get_spacecraft_id()) \
                .set_virtual_channel_id(self.get_virtual_channel_id()) \
                .set_frame_sequence_number(self.increment_virtual_channel_frame_counter(256) if ad_mode else 0) \
                .set_bypass_flag(not ad_mode) \
                .set_control_command_flag(False) \
                .set_security(sec_header, sec_trailer) \
                .set_req_tag(req_tag) \
                .set_operation_tag(operation_tag)
            if self.is_segmented() and is_packet: # If segmentation is enabled and data is packet (not segment) then add segment header
                current_frame.set_segment(TcTransferFrame.SequenceFlagType.NO_SEGMENT, map_id) # Set sequence flag to no segmentation
            current_frame.add_data(data) # Add the transfer frame user data
            to_send = current_frame.build() # Build transfer frame
            self.notify_transfer_frame_generated(to_send, 0) # Store frame in TransferFrameCollector
        # Data length too long, segmentation needed
        else:
            chunks = len(data) // max_data_per_frame + (1 if len(data) % max_data_per_frame > 0 else 0)  # No of tc transfer frames needed
            # Build tc transfer frame for each segment of data
            for cki in range(chunks): 
                sec_header = self.sec_header_supplier() if self.sec_header_supplier else b''
                sec_trailer = self.sec_trailer_supplier() if self.sec_trailer_supplier else b''

                builder = TcTransferFrameBuilder(self.is_fecf_present())
                # Set transfer frame header variables
                current_frame =  builder \
                    .set_spacecraft_id(self.get_spacecraft_id()) \
                    .set_virtual_channel_id(self.get_virtual_channel_id()) \
                    .set_frame_sequence_number(self.increment_virtual_channel_frame_counter(256) if ad_mode else 0) \
                    .set_bypass_flag(not ad_mode) \
                    .set_control_command_flag(False) \
                    .set_security(sec_header, sec_trailer) \
                    .set_req_tag(req_tag) \
                    .set_operation_tag(operation_tag)

                if self.is_segmented(): # If segmentation is enabled, add segment header
                    if cki == 0:
                        current_frame.set_segment(TcTransferFrame.SequenceFlagType.FIRST, map_id) # Set sequence flag to first if it is the first segment
                    elif cki == chunks - 1:
                        current_frame.set_segment(TcTransferFrame.SequenceFlagType.LAST, map_id) # Set sequence flag to last if it is the last segment
                    else:
                        current_frame.set_segment(TcTransferFrame.SequenceFlagType.CONTINUE, map_id) # Set sequence flag to continue for all middle segments 

                curr_offset = cki * max_data_per_frame
                current_frame.add_data(data[curr_offset: curr_offset + max_data_per_frame]) # Add the transfer frame user data 
                to_send = current_frame.build() # Build transfer frame
                self.notify_transfer_frame_generated(to_send, len(data) - curr_offset) # Store frame in TransferFrameCollector

        return 0

    # Return spacecraft id
    def get_spacecraft_id(self) -> int:
        return self.spacecraft_id

    # Return virtual channel id
    def get_virtual_channel_id(self) -> int:
        return self.virtual_channel_id

    # Return virtual channel access mode 
    def get_mode(self) -> VirtualChannelAccessMode:
        return self.mode

    # Return whether fecf present in transfer frames
    def is_fecf_present(self) -> bool:
        return self.fecf_present

    # Return next virtual channel frame counter
    def get_next_virtual_channel_frame_counter(self) -> int:
        return self.virtual_channel_frame_counter.value

    # Set virtual channel frame counter
    def set_virtual_channel_frame_counter(self, number: int) -> None:
        self.virtual_channel_frame_counter.value = number

    # Increment virtual channel frame counter by 1
    def increment_virtual_channel_frame_counter(self, modulus: int) -> int:
        current_counter = self.virtual_channel_frame_counter.value % modulus
        self.virtual_channel_frame_counter.value = 1 if current_counter == 0 else current_counter + 1
        return current_counter

    # Add a listener: TransferFrameCollector/BcFrameCollector (that will store the transfer frames that are built)
    def register(self, listener) -> None:
        self.listeners.append(listener)

    # Remove a listener: TransferFrameCollector/BcFrameCollector (that will store the transfer frames that are built)
    def deregister(self, listener) -> None:
        self.listeners.remove(listener)

    # Request to store transfer frames to all registered listeners (i.e. TransferFrameCollector/BcFrameCollector) 
    # TransferFrameCollector will accept and store AD/BD frames only, BcFrameCollector will accept and store BC frames only
    def notify_transfer_frame_generated(
        self, frame: TcTransferFrame, current_buffered_data: int
    ) -> None:
        self.emitted_frames.increment_and_get()
        for listener in self.listeners:
            listener.transfer_frame_generated(self, frame, current_buffered_data)

    # Return whether there is frame pending
    def is_pending_frame_present(self) -> bool:
        return self.current_frame is not None

    # Return remaining free user length
    def get_remaining_free_space(self) -> int:
        return (
            self.current_frame.get_free_user_data_length()
            if self.current_frame
            else self.get_max_user_data_length()
        )

    # Reset the current frame
    def reset(self) -> None:
        self.current_frame = None

    # Return total number of transfer frames that are built
    def get_nb_of_emitted_frames(self) -> int:
        return self.emitted_frames.get()
    
    # Return max user data length
    def get_max_user_data_length(self):
        builder = TcTransferFrameBuilder(self.is_fecf_present())
        return builder.compute_max_user_data_length() \
            - (1 if self.is_segmented() else 0) \
            - self.sec_header_length \
            - self.sec_trailer_length

