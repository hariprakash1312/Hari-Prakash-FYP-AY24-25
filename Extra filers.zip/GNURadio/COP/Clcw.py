from enum import Enum

class Clcw:
    class CopEffectType(Enum):
        NONE = 0
        COP1 = 1
        RESERVED2 = 2
        RESERVED3 = 3
        
    def __init__(self, ocf):
        if ocf is None or len(ocf) == 0:
            raise ValueError("OCF array is None or has size 0")

        self.ocf = ocf # operational control field i.e. clcw data
        # Check control word type field of clcw (always 0)
        self.clcw = (ocf[0] & 0x80) == 0 
        if not self.clcw:
            raise ValueError("CLCW Type: expected 0, actual 1")

        # Check version number field (00)
        self.version_number = (ocf[0] & 0x60) >> 5 # Check version number
        if self.version_number != 0:
            raise ValueError("CLCW Version Number: expected 0, actual " + str(self.version_number))

        # clcw fields
        self.status_field = (ocf[0] & 0x1C) >> 2

        cop_in_effect_flag = ocf[0] & 0x03
        self.cop_in_effect = self.CopEffectType(cop_in_effect_flag)

        self.virtual_channel_id = (ocf[1] & 0xFC) >> 2
        self.reserved_spare = ocf[1] & 0x03

        self.no_rf_available_flag = (ocf[2] & 0x80) != 0
        self.no_bitlock_flag = (ocf[2] & 0x40) != 0
        self.lockout_flag = (ocf[2] & 0x20) != 0
        self.wait_flag = (ocf[2] & 0x10) != 0
        self.retransmit_flag = (ocf[2] & 0x08) != 0

        self.farm_b_counter = (ocf[2] & 0x06) >> 1
        self.report_value = ocf[3]

    # Return version number
    def get_version_number(self):
        return self.version_number

    # Return status field
    def get_status_field(self):
        return self.status_field

    # Return cop in effect
    def get_cop_in_effect(self):
        return self.cop_in_effect

    # Return virtual channel id
    def get_virtual_channel_id(self):
        return self.virtual_channel_id

    # Return no rf available flag
    def is_no_rf_available_flag(self):
        return self.no_rf_available_flag

    # Return no bitlock flag
    def is_no_bitlock_flag(self):
        return self.no_bitlock_flag

    # Return lockout flag
    def is_lockout_flag(self):
        return self.lockout_flag

    # Return wait flag
    def is_wait_flag(self):
        return self.wait_flag

    # Return retransmit flag
    def is_retransmit_flag(self):
        return self.retransmit_flag

    # Return farm b counter
    def get_farm_b_counter(self):
        return self.farm_b_counter

    # Return report value
    def get_report_value(self):
        return self.report_value

    # Return reserved spare
    def get_reserved_spare(self):
        return self.reserved_spare

    def __str__(self):
        return "Clcw{" + \
               "versionNumber=" + str(self.version_number) + \
               ", statusField=" + str(self.status_field) + \
               ", copInEffect=" + str(self.cop_in_effect) + \
               ", virtualChannelId=" + str(self.virtual_channel_id) + \
               ", reservedSpare=" + str(self.reserved_spare) + \
               ", noRfAvailableFlag=" + str(self.no_rf_available_flag) + \
               ", noBitlockFlag=" + str(self.no_bitlock_flag) + \
               ", lockoutFlag=" + str(self.lockout_flag) + \
               ", waitFlag=" + str(self.wait_flag) + \
               ", retransmitFlag=" + str(self.retransmit_flag) + \
               ", farmBCounter=" + str(self.farm_b_counter) + \
               ", reportValue=" + str(self.report_value) + \
               '}'

    # Return clcw 
    def get_ocf(self):
        return self.ocf

    # Return whether it is a clcw
    def is_clcw(self):
        return self.clcw