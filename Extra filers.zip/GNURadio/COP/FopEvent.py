from enum import Enum

#Enumerate fop events
class FopEvent:
    class EventNumber(Enum):
        E1 = 1
        E2 = 2
        E3 = 3
        E4 = 4
        E5 = 5
        E6 = 6
        E7 = 7
        E101 = 101
        E102 = 102
        E8 = 8
        E9 = 9
        E10 = 10
        E11 = 11
        E12 = 12
        E103 = 103
        E13 = 13
        E14 = 14
        E15 = 15
        E16 = 16
        E104 = 104
        E17 = 17
        E18 = 18
        E19 = 19
        E20 = 20
        E21 = 21
        E22 = 22
        E23 = 23
        E24 = 24
        E25 = 25
        E26 = 26
        E27 = 27
        E28 = 28
        E29 = 29
        E30 = 30
        E31 = 31
        E32 = 32
        E33 = 33
        E34 = 34
        E35 = 35
        E36 = 36
        E37 = 37
        E38 = 38
        E39 = 39
        E40 = 40
        E41 = 41
        E42 = 42
        E43 = 43
        E44 = 44
        E45 = 45
        E46 = 46

    def __init__(self, number, clcw=None, frame=None, directive_tag=None, directive_id=None, directive_qualifier=0, ss=0):
        self.number = number
        self.clcw = clcw
        self.frame = frame
        self.directive_tag = directive_tag
        self.directive_id = directive_id
        self.directive_qualifier = directive_qualifier
        self.ss = ss

    def get_number(self):
        return self.number

    def get_clcw(self):
        return self.clcw

    def get_frame(self):
        return self.frame

    def get_directive_tag(self):
        return self.directive_tag

    def get_directive_id(self):
        return self.directive_id

    def get_directive_qualifier(self):
        return self.directive_qualifier

    def get_suspend_state(self):
        return self.ss
