from enum import Enum

# Enumerate fop alert codes
class FopAlertCode(Enum):
    LIMIT = 1
    T1 = 2
    LOCKOUT = 3
    SYNCH = 4
    NN_R = 5
    CLCW = 6
    LLIF = 7
    TERM = 8
