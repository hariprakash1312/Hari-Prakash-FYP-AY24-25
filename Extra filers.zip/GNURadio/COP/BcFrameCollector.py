from typing import Optional
from overall_TcSenderVirtualChannel import TcSenderVirtualChannel
from overall_TcTransferFrame import TcTransferFrame

# Store BC frames, where the TcSenderVirtualChannel will put in BC frames created and FopEngine will retrieve BC frames
class BcFrameCollector:
    def __init__(self, virtual_channel: TcSenderVirtualChannel):
        self.virtual_channel = virtual_channel
        self.virtual_channel.register(self)
        self.filter_predicate = TcTransferFrame.FrameType.BC
        self.frame_list = []

    # Return a BC Set V(R) transfer frame
    def apply(self, set_vr: int, tag: int) -> Optional[TcTransferFrame]:
        self.retrieve() # Clear current list of frames
        self.virtual_channel.dispatch_set_vr(set_vr,tag) # Ask virtual channel to make a BC frame for set v(r), which will be stored in frame_list
        return self.retrieve_first(True) # Retrieve and return the BC frame from frame_list

    # Return a BC Unlock transfer frame
    def get(self, tag: int) -> Optional[TcTransferFrame]:
        self.retrieve() # Clear current list of frames
        self.virtual_channel.dispatch_unlock(tag) # Ask virtual channel to make a BC frame for unlock, which will be stored in frame_list
        return self.retrieve_first(True) # Retrieve and return the BC frame from frame_list

    # Return and remove first frame from frame_list (if exists), clear list if clear_list = True
    def retrieve_first(self, clear_list=True):
        first_frame = self.frame_list.pop(0) if self.frame_list else None
        if clear_list:
            self.frame_list.clear()
        return first_frame

    # Return a copy of the current frame_list and clears frame_list
    def retrieve(self):
        copied_list = self.frame_list.copy()
        self.frame_list.clear()
        return copied_list

    # Add generated_frame to frame_list if it is a BC frame
    def transfer_frame_generated(self, virtual_channel, generated_frame, buffered_bytes):
        if (self.filter_predicate == generated_frame.get_frame_type()):
            self.frame_list.append(generated_frame)

