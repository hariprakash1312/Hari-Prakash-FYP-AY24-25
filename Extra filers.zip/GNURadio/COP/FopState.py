from enum import Enum

# Enumerate fop states
class FopState(Enum):
    
    # Normal state of the state machine when there are no recent errors on
    # the link and no incidents have occurred leading to flow control problems
    S1 = "Active"  # Active
    # The state machine is in the 'Retransmit without Wait' State (S2) while the 'Retransmit' Flag
    # is 'on' in the CLCW of the Virtual Channel but no other exceptional circumstances prevail.
    S2 = "Retransmit without wait"  # Retransmit without wait
    # The state machine is in the 'Retransmit with Wait' State (S3) while the 'Wait' Flag is 'on' in
    # the CLCW of the Virtual Channel. (Some Transfer Frames must always be retransmitted
    # when the 'Wait' Flag is reset, since the 'Wait' Flag is set only when at least one Transfer
    # Frame has been discarded.) In this state the 'Retransmit' Flag will also be set (as a
    # consequence of the fact that Transfer Frames have been lost).
    S3 = "Retransmit with wait"  # Retransmit with wait
    # The state machine is in the 'Initializing without BC Frame' State (S4) after receiving an
    # 'Initiate AD Service (with CLCW check)' Directive while in the 'Initial' State. A successful
    # CLCW check will result in a transition to S1.
    S4 = "Initializing without BC Frame"  # Initialising without BC Frame
    # The state machine is in the 'Initializing with BC Frame' State (S5) after receiving an 'Initiate
    # AD Service (with Unlock)' Directive or 'Initiate AD Service (with Set V(R))' Directive
    # while in the 'Initial' State with BC_Out_Flag = Ready. A successful transmission of the
    # Type-BC Transfer Frame and a subsequent 'clean' CLCW status will result in a transition to
    # S1.
    S5 = "Initializing with BC Frame"  # Initialising with BC Frame
    # The state machine is in the 'Initial' State (S6) whenever it is necessary to terminate an
    # ongoing service (this happens when a 'Terminate AD Service' Directive is received or when
    # an 'exception', i.e., an event that causes an 'Alert', occurs). In principle, the 'Initial' State is
    # the first state entered by the state machine for a particular Virtual Channel.
    # State S6 shall also be used when the AD Service is suspended.
    S6 = "Initial"  # Initial

    def __str__(self):
        descriptions = {
            FopState.S1: "Active",
            FopState.S2: "Retransmit without wait",
            FopState.S3: "Retransmit with wait",
            FopState.S4: "Initialising without BC Frame",
            FopState.S5: "Initialising with BC Frame",
            FopState.S6: "Initial",
        }
        return f"{self.name} - {descriptions[self]}"
