from overall_FopEvent import FopEvent
from overall_FopAlertCode import FopAlertCode
from overall_FopState import FopState
from overall_S2FopState import S2FopState
from overall_S3FopState import S3FopState
from overall_S6FopState import S6FopState
from overall_AbstractFopState import AbstractFopState

# Define the actions required and the appropriate methods to call for FOP-1 events while in FOP-1 state S1
class S1FopState(AbstractFopState):
    def __init__(self, engine):
        super().__init__(engine)

    # Registering event handlers for different FOP events
    def register_handlers(self):
        self.event2handler = {
            FopEvent.EventNumber.E1: self.ignore,
            FopEvent.EventNumber.E2: self.e2,
            FopEvent.EventNumber.E3: self.e3e7e15,
            FopEvent.EventNumber.E4: self.e4,
            FopEvent.EventNumber.E5: self.ignore,
            FopEvent.EventNumber.E6: self.e6,
            FopEvent.EventNumber.E7: self.e3e7e15,
            FopEvent.EventNumber.E101: self.e101,
            FopEvent.EventNumber.E102: self.e102,
            FopEvent.EventNumber.E8: self.e8,
            FopEvent.EventNumber.E9: self.e9,
            FopEvent.EventNumber.E10: self.e10,
            FopEvent.EventNumber.E11: self.e11,
            FopEvent.EventNumber.E12: self.e12,
            FopEvent.EventNumber.E103: self.e103,
            FopEvent.EventNumber.E13: self.e13,
            FopEvent.EventNumber.E14: self.e14,
            FopEvent.EventNumber.E15: self.e3e7e15,
            FopEvent.EventNumber.E16: self.e16e104,
            FopEvent.EventNumber.E104: self.e16e104,
            FopEvent.EventNumber.E17: self.e17,
            FopEvent.EventNumber.E18: self.e18,
            FopEvent.EventNumber.E19: self.e19,
            FopEvent.EventNumber.E20: self.reject,
            FopEvent.EventNumber.E21: self.e21,
            FopEvent.EventNumber.E22: self.reject,
            FopEvent.EventNumber.E23: self.reject,
            FopEvent.EventNumber.E24: self.reject,
            FopEvent.EventNumber.E25: self.reject,
            FopEvent.EventNumber.E26: self.reject,
            FopEvent.EventNumber.E27: self.reject,
            FopEvent.EventNumber.E28: self.reject,
            FopEvent.EventNumber.E29: self.e29,
            FopEvent.EventNumber.E30: self.reject,
            FopEvent.EventNumber.E35: self.reject,
            FopEvent.EventNumber.E36: self.e36,
            FopEvent.EventNumber.E37: self.e37,
            FopEvent.EventNumber.E38: self.e38,
            FopEvent.EventNumber.E39: self.e39,
            FopEvent.EventNumber.E40: self.reject,
            FopEvent.EventNumber.E41: self.e41,
            FopEvent.EventNumber.E42: self.e42,
            FopEvent.EventNumber.E43: self.e43,
            FopEvent.EventNumber.E44: self.e44,
            FopEvent.EventNumber.E45: self.e45,
            FopEvent.EventNumber.E46: self.e46,
        }

    # Return the current state
    def get_state(self):
        return FopState.S1
    
    # Handler functions for different events
    def e2(self, fop_event):
        self.engine.remove_ack_frames_from_sent_queue(fop_event.get_clcw())
        self.engine.cancel_timer()
        self.engine.look_for_frame()
        return self

    def e3e7e15(self, fop_event):
        self.engine.alert(FopAlertCode.CLCW)
        return S6FopState(self.engine)

    def e4(self, fop_event):
        self.engine.alert(FopAlertCode.SYNCH)
        return S6FopState(self.engine)

    def e6(self, fop_event):
        self.engine.remove_ack_frames_from_sent_queue(fop_event.get_clcw())
        self.engine.look_for_frame()
        return self

    def e101(self, fop_event):
        self.engine.remove_ack_frames_from_sent_queue(fop_event.get_clcw())
        self.engine.alert(FopAlertCode.LIMIT)
        return S6FopState(self.engine)

    def e102(self, fop_event):
        self.engine.alert(FopAlertCode.LIMIT)
        return S6FopState(self.engine)

    def e8(self, fop_event):
        self.engine.remove_ack_frames_from_sent_queue(fop_event.get_clcw())
        self.engine.initiate_ad_retransmission()
        self.engine.look_for_frame()
        return S2FopState(self.engine)

    def e9(self, fop_event):
        self.engine.remove_ack_frames_from_sent_queue(fop_event.get_clcw())
        return S3FopState(self.engine)

    def e10(self, fop_event):
        self.engine.initiate_ad_retransmission()
        self.engine.look_for_frame()
        return S2FopState(self.engine)

    def e11(self, fop_event):
        return S3FopState(self.engine)

    def e12(self, fop_event):
        return S2FopState(self.engine)

    def e103(self, fop_event):
        return S3FopState(self.engine)

    def e13(self, fop_event):
        self.engine.alert(FopAlertCode.NN_R)
        return S6FopState(self.engine)

    def e14(self, fop_event):
        self.engine.alert(FopAlertCode.LOCKOUT)
        return S6FopState(self.engine)

    def e16e104(self, fop_event):
        self.engine.initiate_ad_retransmission()
        self.engine.look_for_frame()
        return self

    def e17(self, fop_event):
        self.engine.alert(FopAlertCode.T1)	
        return S6FopState(self.engine)

    def e18(self, fop_event):
        self.engine.set_suspend_state(1)
        self.engine.suspend()
        return S6FopState(self.engine)

    def e19(self, fop_event):
        self.engine.add_to_wait_queue(fop_event)
        self.engine.look_for_frame()
        return self

    def e41(self, fop_event):
        self.engine.set_ad_out_ready_flag(True)
        self.engine.look_for_frame()
        return self

    def e43(self, fop_event):
        self.engine.set_bc_out_ready_flag(True)
        return self



