
from typing import Callable, List
import threading
from threading import Thread, Timer
from concurrent.futures import ThreadPoolExecutor, TimeoutError
import time

from overall_FopOperationStatus import FopOperationStatus
from overall_IFopObserver import IFopObserver
from overall_TcTransferFrame import TcTransferFrame
from overall_Clcw import Clcw
from overall_FopDirective import FopDirective
from overall_S6FopState import S6FopState
from overall_FopEvent import FopEvent
from overall_FopStatus import FopStatus

# Multi-thread increment, decrement, get value of a shared integer
class AtomicReference:
    def __init__(self, initial_value=None):
        self._value = initial_value
        self._lock = threading.Lock()
        self._condition = threading.Condition(self._lock)

    def get(self):
        with self._lock:
            return self._value

    def set(self, new_value):
        with self._lock:
            self._value = new_value
            self._condition.notify_all()
            
    def get_and_set(self, new_value):
        with self._lock:
            old_value = self._value
            self._value = new_value
            return old_value
        
    def notify_all(self):
        with self._lock:
            self._condition.notify_all()
    

# Contains most of the methods that define the logic and actions to be taken upon receiving input directives/transfer request/ CLCW
class FopEngine:

    def __init__(self,
                 virtual_channel_id: int,
                 next_virtual_channel_frame_counter_getter: Callable[[], int],
                 next_virtual_channel_frame_counter_setter: Callable[[int], None],
                 bc_frame_unlock_factory: Callable[[int], TcTransferFrame],
                 bc_frame_set_vr_factory: Callable[[int,int], TcTransferFrame],
                 output: Callable[[TcTransferFrame], bool],
                 timer_initial_value,
                 transmission_limit,
                 timeout_type,
                 fop_sliding_window):

        self.virtual_channel_id = virtual_channel_id
        # Function to obtain the Transmitter_Frame_Sequence_Number (V(S))
        self.next_virtual_channel_frame_counter_getter = next_virtual_channel_frame_counter_getter  
        # Function to set the Transmitter_Frame_Sequence_Number (V(S))
        self.next_virtual_channel_frame_counter_setter = next_virtual_channel_frame_counter_setter
        # Function to obtain a BC unlock frame
        self.bc_frame_unlock_factory = bc_frame_unlock_factory 
        # Function to obtain a BC set V(R) frame
        self.bc_frame_set_vr_factory = bc_frame_set_vr_factory 
        # Executor for handling FOP entity processing tasks with a single worker thread
        self.fop_executor = ThreadPoolExecutor(max_workers=1, thread_name_prefix=f"FOP Entity Processor for TC VC {virtual_channel_id}")
        # Executor for handling low-level FOP tasks with a single worker thread
        self.low_level_executor = ThreadPoolExecutor(max_workers=1, thread_name_prefix=f"FOP Entity Low Level for TC VC {virtual_channel_id}")
        self.confinement_thread = threading.current_thread()
        # List of observers for FOP responses/alerts
        self.observers: List[IFopObserver] = []
        # Atomic references for managing pending actions and results
        self.pending_accept_reject_result = AtomicReference() # Result of a pending accept/reject operation
        self.pending_accept_reject_frame = AtomicReference() # Frame associated with a pending accept/reject operation
        self.pending_event_result = AtomicReference() # Result of a pending event
        self.pending_init_ad = AtomicReference() # Pending AD initialization
        self.wait_queue = AtomicReference(None) # Queue for holding FDUs waiting for acceptance

        # Function to forward transfer frames as output of Fop Engine
        self.output = output
        self.output_lock = threading.Lock()

        # Timer for transmit timeout
        self.current_timer: Optional[Timer] = None
        self.fop_timer_lock = threading.Lock()

        # FOP Variables
        
        # When Type-AD FDUs are received from the Higher Procedures, they shall be held in the Wait_Queue until they can be accepted 
        # by FOP-1. The Wait_Queue has a maximum capacity of one FDU. The Wait_Queue and 'Accept Response to Request to Transfer FDU' 
        # form the primary mechanism by which flow control as seen by the Higher Procedures is governed. When an FDU is on the Wait_Queue,
        # this means that the Higher Procedures have not yet received an 'Accept Response' for the corresponding 'Request to Transfer FDU'.

        # # Flag indicating whether a 'Transmit Request for Frame' can be sent for AD frames
        self.ad_out_ready_flag = True
        # Flag indicating whether a 'Transmit Request for Frame' can be sent for BD frames
        self.bd_out_ready_flag = True
        # Flag indicating whether a 'Transmit Request for Frame' can be sent for BC frames
        self.bc_out_ready_flag = True
        # Queue for holding all Type-AD and Type-BC Transfer Frames between the time a copy of the Transfer Frame is first 
        # passed to the Lower Procedures for transmission, and the time the FOP-1 has finished processing the Transfer Frame.
        self.sent_queue: List[self.TransferFrameStatus] = []
        # The expected_ack_frame_sequence_number, NN(R), contains the Frame Sequence Number of the oldest unacknowledged AD Frame, 
        # which is on the Sent_Queue. This value is often equal to the value of N(R) from the previous CLCW on that Virtual Channel.
        self.expected_ack_frame_sequence_number = 0 #NN(R)
        # Whenever a Type-AD or Type-BC Transfer Frame is transmitted, the Timer shall be started
        # or restarted with an initial value of Timer_Initial_Value (T1_Initial).
        self.timer_initial_value = timer_initial_value
        # The Transmission_Limit holds a value which represents the maximum number of times the first Transfer Frame on the Sent_Queue 
        # may be transmitted. This includes the first 'transmission' and any subsequent 'retransmissions' of the Transfer Frame.
        self.transmission_limit = transmission_limit
        # The Timeout_Type variable may take one of two values, '0' or '1'. It specifies the action to be performed when both the Timer 
        # expires and the Transmission_Count has reached the Transmission_Limit.
        self.timeout_type = timeout_type  #TT
        # The Transmission_Count variable is used to count the number of transmissions of the first Transfer Frame on the Sent_Queue. 
        # The Transmission_Count shall be incremented each time the first Transfer Frame is retransmitted.
        self.transmission_count = 0
        # The Suspend_State variable may take one of five values, from '0' to '4'. It records the state that FOP-1 was in when the AD Service was suspended. 
        # This is the state to which FOP-1 will return should the AD Service be resumed. If SS = 0, the AD Service is deemed not suspended.
        self.suspend_state = 0  #SS
        # The FOP Sliding Window is a mechanism which limits the number of Transfer Frames which can be transmitted ahead of the last acknowledged Transfer Frame, 
        # i.e., before a CLCW report is received which updates the status of acknowledged Transfer Frames. This is done
        # to prevent sending a new Transfer Frame with the same sequence number as a rejected Transfer Frame.
        self.fop_sliding_window = fop_sliding_window  #K
        # State of FOP-1 for the specific Virtual Channel
        self.state = S6FopState(self)   

    # Return the TC virtual channel ID
    def get_virtual_channel_id(self) -> int:
        return self.virtual_channel_id

    # Register an IFopObserver as listener to FOP state changes, alerts and suspends notifications, as well as transfer frame and directive notifications
    def register(self, observer) -> None:
        self.observers.append(observer)

    # Deregister an IFopObserver listener
    def deregister(self, observer) -> None:
        self.observers.remove(observer)


# ---------------------------------------------------------------------------------------------------------
# FOP-1 public operations as per CCSDS definition for event injection
# ---------------------------------------------------------------------------------------------------------

    # Request the FOP engine to execute a COP-1 directive.
    # param tag: the request tag, which will be returned in the callback on the IFopObserver interface
    # param directive: the directive ID
    # param qualifier: the directive qualifier: if not meaningful, this argument can assume any value
    def directive(self, tag, directive, qualifier) -> None:
        self.fop_executor.submit(lambda: self.process_directive(tag, directive, qualifier))

    # Request the FOP engine to transmit a AD or BD frame
    # param frame: the frame to transmit
    # param timeout_millis: the timeout in milliseconds waiting for acceptance or rejection of the request
    # return true if the request was accepted, false it is was rejected or the timeout expired
    def transmit(self, frame, timeout_millis) -> bool:
        expiration_time = timeout_millis / 1000.0
        if frame.get_frame_type() == TcTransferFrame.FrameType.BD:
            response = self.transmit_sync_bd(frame, expiration_time)
            return response
        elif frame.get_frame_type() == TcTransferFrame.FrameType.AD:
            response = self.transmit_sync_ad(frame, expiration_time)
            return response
        else:
            raise ValueError("This method can be invoked only for BD and AD frames")

    # BD frames can be unblocked as soon as a REJECT_RESPONSE is received (event E22), or events E45 or E46 are received.
    # param frame: the frame to send
    # param expiration_time: the timeout in seconds waiting for acceptance or rejection of the request
    # return true if the request was accepted, false it is was rejected or the timeout expired           
    def transmit_sync_bd(self, frame, expiration_time) -> bool:
        self.pending_accept_reject_frame.set(frame)
        self.pending_event_result.set(None)
        self.transmit_type(frame) # Request to transmit frame
        start_time = time.time()
        while True:
            if self.pending_event_result.get() is not None: # Request accepted/rejected
                operation_result = self.pending_event_result.get_and_set(None)
                self.pending_accept_reject_frame.set(None)
                return operation_result == FopEvent.EventNumber.E45

            elapsed_time = time.time() - start_time
            if elapsed_time >= expiration_time: # Timeout expired while waiting for acceptance/rejection of request
                break
            time.sleep(0.1) 
        return False

    # AD frames can be unblocked as soon as an ACCEPT_RESPONSE or REJECT_RESPONSE is received.
    # param frame: the frame to send
    # param expiration_time: the timeout in seconds waiting for acceptance or rejection of the request
    # return true if the request was accepted, false it is was rejected or the timeout expired        
    def transmit_sync_ad(self, frame, expiration_time) -> bool:
        self.pending_accept_reject_frame.set(frame)
        self.pending_accept_reject_result.set(None)
        self.transmit_type(frame) # Request to transmit frame
        start_time = time.time()
        while True:
            if self.pending_accept_reject_result.get() is not None: # Request accepted/rejected
                operation_result = self.pending_accept_reject_result.get_and_set(None)
                self.pending_accept_reject_frame.set(None)
                return operation_result == FopOperationStatus.ACCEPT_RESPONSE

            elapsed_time = time.time() - start_time
            if elapsed_time >= expiration_time: # Timeout expired while waiting for acceptance/rejection of request
                print("fop sliding window full, tc frame in wait queue")
                break
            time.sleep(0.1) 
        return False

    # Transmit a AD or BD frame
    # param frame: the frame to transmit
    def transmit_type(self, frame):
        if frame.get_frame_type() == TcTransferFrame.FrameType.BD:
            self.process_bd_frame(frame)
        elif frame.get_frame_type() == TcTransferFrame.FrameType.AD:
            self.process_ad_frame(frame)
        else:
            raise ValueError(f"This method can be invoked only for BD and AD frames")

    # Inform the FOP entity about the arrival of a new CLCW. The CLCW is processed only if reports COP-1 in effect, and
    # matches the virtual channel specified for FOP engine
    # param clcw: the CLCW to process
    def clcw(self, clcw):
        if clcw.get_cop_in_effect() == Clcw.CopEffectType.COP1 and clcw.get_virtual_channel_id() == self.virtual_channel_id:
            self.fop_executor.submit(lambda: self.process_clcw(clcw))

    # Dispose the FOP entity
    def dispose(self) -> None:
        self.fop_executor.submit(self.cancel_timer) 
        self.fop_executor.submit(self.purge_wait_queue) 
        self.fop_executor.submit(self.purge_sent_queue)
        self.fop_executor.shutdown() 
        try:
            self.fop_executor.shutdown(wait=True, timeout=1)
        except TimeoutError:
            # Handle timeout if the executor is still running after 1 second
            Thread.currentThread().interrupt()
        self.low_level_executor.shutdown_now()

    # ---------------------------------------------------------------------------------------------------------
    # FOP-1 actions defined as per CCSDS definition. All these actions are performed by the state transitions
    # and executed by the fopExecutor service. Thread access is enforced to avoid misuse.
    # ---------------------------------------------------------------------------------------------------------

    # Clear the sent_queue by generating a 'Negative Confirm Response to Request to Transfer FDU' for each Transfer Frame on the queue and deleting the Transfer Frame
    def purge_sent_queue(self) -> None:
        for tfs in self.sent_queue:
            if tfs.get_frame().get_frame_type() == TcTransferFrame.FrameType.BC and self.pending_init_ad.get() is not None:
                # Directive (not on the standard)
                directive = self.pending_init_ad.get_and_set(None)
                for o in self.observers:
                    o.directive_notification(self, FopOperationStatus.NEGATIVE_CONFIRM, directive[0], directive[1], directive[2])
            else:
                # Frame
                for o in self.observers:
                    o.transfer_notification(self, FopOperationStatus.NEGATIVE_CONFIRM, tfs.get_frame())
        self.sent_queue.clear()

    # Clear the Wait_Queue and generating a 'Reject Response to Request to Transfer FDU' for the queued FDU
    def purge_wait_queue(self) -> None:
        if self.wait_queue.get() is not None:
            self.reject(self.wait_queue.get())
        self.wait_queue.set(None)

    # Includes all the functions necessary to prepare a Type-AD Transfer Frame for transmission
    # param frame: the frame to send
    def transmit_type_ad_frame(self, frame) -> None:
        sent_queue_was_empty = len(self.sent_queue) == 0
        self.sent_queue.append(self.TransferFrameStatus(frame)) # Add frame to sent_queue
        if sent_queue_was_empty:
            self.transmission_count = 1
        self.restart_timer() # Start transmit timeout timer
        self.set_ad_out_ready_flag(False)
        self.low_level_executor.submit(lambda: self.forward_to_output(frame)) # Forward frame to output and generate the necessary response

    # Includes all the functions necessary to prepare a Type-BC Transfer Frame for transmission
    # param frame: the frame to send
    def transmit_type_bc_frame(self, frame) -> None:
        self.sent_queue.append(self.TransferFrameStatus(frame)) # Add frame to sent_queue
        self.transmission_count = 1
        self.restart_timer()
        self.set_bc_out_ready_flag(False)
        self.low_level_executor.submit(lambda: self.forward_to_output(frame)) # Forward frame to output and generate the necessary response

    # Includes all the functions necessary to prepare a Type-BD Transfer Frame for transmission
    # param frame: the frame to send
    def transmit_type_bd_frame(self, frame) -> None:
        self.set_bd_out_ready_flag(False)
        self.low_level_executor.submit(lambda: self.forward_to_output(frame)) # Forward frame to output and generate the necessary response
    
    # Flag AD frames in sent_queue as to be retransmitted
    def initiate_ad_retransmission(self) -> None:
        self.transmission_count += 1
        self.restart_timer()
        for o in self.sent_queue:
            if o.get_frame().get_frame_type() == TcTransferFrame.FrameType.AD:
                o.set_to_be_retransmitted(True)

    # Flag BC frames in sent_queue as to be retransmitted
    def initiate_bc_retransmission(self):
        self.transmission_count += 1
        self.restart_timer() 
        for o in self.sent_queue:
            if o.get_frame().get_frame_type() == TcTransferFrame.FrameType.BC:
                o.set_to_be_retransmitted(True)

    # Remove acknowledged frames from sent_queue
    # param clcw: the CLCW
    def remove_ack_frames_from_sent_queue(self, clcw):
        acked = True
        nr_report_value = clcw.get_report_value()
        expander = {(nr_report_value - 1 - i + 256) % 256 for i in range(self.fop_sliding_window)} # Set of values indicating NN(R) of accepted frames
        while acked and len(self.sent_queue) > 0:
            next_ = self.sent_queue[0]
            if next_.get_frame().get_frame_type() == TcTransferFrame.FrameType.BC:
                raise RuntimeError("No BC frames should be present in the sent queue when calling remove_ack_frames_from_sent_queue()")

            current_nnr = next_.get_frame().get_virtual_channel_frame_count() # Get NN(R) of oldest frame in sent_queue
            if current_nnr in expander:
                self.confirm(next_.get_frame()) # Send positive confirm response for frame
                self.sent_queue.pop(0) # Remove frame from sent queue
                self.expected_ack_frame_sequence_number = (self.expected_ack_frame_sequence_number + 1) % 256 # Update NN(R)
                self.transmission_count = 1 # Reset transmission_count to 1
                acked = True
            else:
                acked = False

    # Look for BC frames flagged as to retransmit in sent_queue and initiate retransmission 
    def look_for_directive(self):
        if not self.bc_out_ready_flag:
            pass
        else:
            opt_bc_frame = next((o for o in self.sent_queue if o.get_frame().get_frame_type() == TcTransferFrame.FrameType.BC and o.is_to_be_retransmitted()), None)
            if opt_bc_frame is not None:
                self.set_bc_out_ready_flag(False)
                opt_bc_frame.set_to_be_retransmitted(False)
                self.low_level_executor.submit(lambda: self.forward_to_output(opt_bc_frame.get_frame()))

    # Look for AD frames flagged as to retransmit in sent_queue and initiate retransmission or look for AD frame in wait_queue and transmit 
    def look_for_frame(self):
        if not self.ad_out_ready_flag:
            pass
        else:
            opt_ad_frame = next((o for o in self.sent_queue if o.get_frame().get_frame_type() == TcTransferFrame.FrameType.AD and o.is_to_be_retransmitted()), None)
            if opt_ad_frame is not None: # Initiate retransmission if there are AD frames to retransmit
                opt_ad_frame.set_to_be_retransmitted(False)
                self.set_ad_out_ready_flag(False)
                self.low_level_executor.submit(lambda: self.forward_to_output(opt_ad_frame.get_frame()))
            else: # Transmit AD frame in wait_queue if fop_sliding_window not exceeded
                if self.wait_queue.get() is not None and self.wait_queue.get().get_frame_type() == TcTransferFrame.FrameType.AD and self.less_than(self.wait_queue.get().get_virtual_channel_frame_count(), (self.expected_ack_frame_sequence_number + self.fop_sliding_window), self.fop_sliding_window):
                    to_transmit = self.wait_queue.get_and_set(None)
                    self.accept(to_transmit)
                    self.transmit_type_ad_frame(to_transmit)
                else:
                    pass

    # Generate accept response to frame transfer request
    # param frame: the frame to notify as accepted
    def accept(self, frame):
        for o in self.observers:
            o.transfer_notification(self, FopOperationStatus.ACCEPT_RESPONSE, frame)
        if self.pending_accept_reject_frame.get() == frame:
            self.pending_accept_reject_result.set(FopOperationStatus.ACCEPT_RESPONSE)
            self.pending_accept_reject_frame.notify_all()

    # Generate accept response to directive request
    # param tag: the directive tag to report as accepted
    # param directive: the directive type
    # param qualifier: the qualifier
    def accept_directive(self, tag, directive, qualifier):
        for o in self.observers:
            o.directive_notification(self, FopOperationStatus.ACCEPT_RESPONSE, tag, directive, qualifier)

    # Generate reject response to frame transfer request
    # param frame: the frame to notify as rejected
    def reject(self, frame):
        if self.pending_accept_reject_frame.get() == frame:
            self.pending_accept_reject_result.set(FopOperationStatus.ACCEPT_RESPONSE)
            self.pending_accept_reject_frame.notify_all()
        for o in self.observers:
            o.transfer_notification(self, FopOperationStatus.REJECT_RESPONSE, frame)

    # Generate reject response to directive request
    # param tag: the directive tag to report as rejected
    # param directive: the directive type
    # param qualifier: the qualifier
    def reject_directive(self, tag, directive, qualifier):
        for o in self.observers:
            o.directive_notification(self, FopOperationStatus.REJECT_RESPONSE, tag, directive, qualifier)

    # Reject called by event handlers of the fop state
    # param fop_event: the event linked to the action to reject
    def reject_event(self, fop_event):
        if fop_event.get_frame() is not None:
            self.reject(fop_event.get_frame())
        elif fop_event.get_directive_id() is not None:
            self.reject_directive(fop_event.get_directive_tag(), fop_event.get_directive_id(), fop_event.get_directive_qualifier())
        else:
            raise ValueError("FOP event " + fop_event.get_directive_id() + " not recognised for reject")

    # Generate positive confirm response to frame transfer request
    def confirm(self, frame):
        for o in self.observers:
            o.transfer_notification(self, FopOperationStatus.POSITIVE_CONFIRM, frame)

    # Generate positive confirm response to directive request
    def confirm_directive(self, tag, directive, qualifier):
        for o in self.observers:
            o.directive_notification(self, FopOperationStatus.POSITIVE_CONFIRM, tag, directive, qualifier)

    # Add frame to wait_queue
    def add_to_wait_queue(self, fop_event):
        self.wait_queue.set(fop_event.get_frame())

    # Initialise fop engine for AD service
    def initialise(self):
        self.purge_sent_queue()
        self.purge_wait_queue()
        self.transmission_count = 1
        self.suspend_state = 0

    # Generate alert code 
    # param code: the alert code
    def alert(self, code):
        self.cancel_timer()
        self.purge_sent_queue()
        self.purge_wait_queue()
        for o in self.observers:
            o.alert(self, code)

    # Generate suspend notification
    def suspend(self):
        for o in self.observers:
            o.suspend(self)

    # Resume AD service
    def resume(self):
        self.restart_timer()
        self.suspend_state = 0

    # Restart transmit timeout timer
    def restart_timer(self):
        with self.fop_timer_lock:
            if self.current_timer is not None:
              self.current_timer.cancel()
              self.current_timer = None
            self.current_timer = Timer(self.timer_initial_value, self.timer_expired)
            self.current_timer.start()

    # Cancel transmit timeout timer
    def cancel_timer(self):
        if self.current_timer is not None:
            self.current_timer.cancel()
            self.current_timer = None

    # Set fop_sliding_window value
    def set_fop_sliding_window(self, fop_sliding_window):
        self.fop_sliding_window = fop_sliding_window
        print("Fop Sliding Window set to: ", fop_sliding_window)

    # Set transmit timeout t1 initial value
    def set_t1_initial(self, t1_initial):
        self.timer_initial_value = t1_initial
        print("T1 initial set to: ", t1_initial)

    # Set transmission limit value
    def set_transmission_limit(self, limit):
        self.transmission_limit = limit
        print("Transmission limit set to: ", limit)

    # Set timeout type
    def set_timeout_type(self, type_):
        self.timeout_type = type_
        print("Timeout type set to: ", type_)

    # Set ad_out_ready_flag
    def set_ad_out_ready_flag(self, flag):
        self.ad_out_ready_flag = flag

    # Set bc_out_ready_flag
    def set_bc_out_ready_flag(self, flag):
        self.bc_out_ready_flag = flag

    # Set bd_out_ready_flag
    def set_bd_out_ready_flag(self, flag):
        self.bd_out_ready_flag = flag
        self.pending_accept_reject_frame.notify_all()

    # Request the FOP engine to transmit a BC unlock frame
    def transmit_type_bc_frame_unlock(self, tag):
        frame = self.bc_frame_unlock_factory(tag)
        self.transmit_type_bc_frame(frame)

    # Request the FOP engine to transmit a BC Set V(R) frame
    def transmit_type_bc_frame_set_vr(self, tag, vr):
        frame = self.bc_frame_set_vr_factory(vr,tag)
        self.transmit_type_bc_frame(frame)

    # Set suspend state ss
    def set_suspend_state(self, suspend_state):
        self.suspend_state = suspend_state

    # Update transmitter frame sequence number V(S) and expected_ack_frame_sequence_number NN(R) based on the new V(R) value
    def prepare_for_set_vr(self, vstarr):
        self.next_virtual_channel_frame_counter_setter(vstarr)
        self.expected_ack_frame_sequence_number = vstarr

    # Set transmitter frame sequence number V(S) 
    def set_vs(self, vstars):
        self.next_virtual_channel_frame_counter_setter(vstars)
        self.expected_ack_frame_sequence_number = vstars
        print("V(S) set to: ", vstars)

    # Register initiate AD directive
    def register_pending_init_ad(self, directive_tag, directive_id, directive_qualifier):
        self.pending_init_ad.set([directive_tag, directive_id, directive_qualifier])

    # Confirm initialisation by initiate AD with CLCW directive
    def confirm_pending_init_ad_with_clcw(self, clcw):
        pending_directive = self.pending_init_ad.get_and_set(None)
        if pending_directive is not None:
            self.set_vs(clcw.get_report_value())
            self.confirm_directive(pending_directive[0], pending_directive[1], pending_directive[2])

    # Confirm initialisation by initiate AD with Unlock/Set V(R) directive
    def confirm_pending_init_ad_with_bc_frame(self):
        pending_directive = self.pending_init_ad.get_and_set(None)
        if pending_directive is not None:
            self.confirm_directive(pending_directive[0], pending_directive[1], pending_directive[2])

    # Remove BC frame from sent_queue
    def release_bc_frame(self):
        opt_bc_frame = next((o for o in self.sent_queue if o.get_frame().get_frame_type() == TcTransferFrame.FrameType.BC), None)
        if opt_bc_frame is not None:
            self.sent_queue.remove(opt_bc_frame)

    # ---------------------------------------------------------------------------------------------------------
    # FOP-1 methods performed by the fopExecutor (thread confinement)
    # ---------------------------------------------------------------------------------------------------------
    # Determine FopEvent event based on CLCW received
    def process_clcw(self, clcw):
        event = None
        print("N(R)=",clcw.get_report_value())
        print("V(S)=",self.next_virtual_channel_frame_counter_getter())
        print("NN(R)=",self.expected_ack_frame_sequence_number)
        if not clcw.is_lockout_flag():
            if clcw.get_report_value() == self.next_virtual_channel_frame_counter_getter():
                if not clcw.is_retransmit_flag():
                    if not clcw.is_wait_flag():
                        if clcw.get_report_value() == self.expected_ack_frame_sequence_number:
                            event = FopEvent(FopEvent.EventNumber.E1, clcw=clcw, ss=self.suspend_state)
                        else:
                            event = FopEvent(FopEvent.EventNumber.E2, clcw=clcw, ss=self.suspend_state)
                    else:
                        event = FopEvent(FopEvent.EventNumber.E3, clcw=clcw, ss=self.suspend_state)
                else:
                    event = FopEvent(FopEvent.EventNumber.E4, clcw=clcw, ss=self.suspend_state)
            elif self.less_than(clcw.get_report_value(), self.next_virtual_channel_frame_counter_getter(), self.fop_sliding_window) and (clcw.get_report_value() == self.expected_ack_frame_sequence_number or self.greater_than(clcw.get_report_value(), self.expected_ack_frame_sequence_number, self.fop_sliding_window)):
                if not clcw.is_retransmit_flag():
                    if not clcw.is_wait_flag():
                        if clcw.get_report_value() == self.expected_ack_frame_sequence_number:
                            event = FopEvent(FopEvent.EventNumber.E5, clcw=clcw, ss=self.suspend_state)
                        else:
                            event = FopEvent(FopEvent.EventNumber.E6, clcw=clcw, ss=self.suspend_state)
                    else:
                        event = FopEvent(FopEvent.EventNumber.E7, clcw=clcw, ss=self.suspend_state)
                else:
                    if self.transmission_limit == 1:
                        event = FopEvent(FopEvent.EventNumber.E101 if clcw.get_report_value() != self.expected_ack_frame_sequence_number else FopEvent.EventNumber.E102, clcw=clcw, ss=self.suspend_state)
                    else:
                        if clcw.get_report_value() != self.expected_ack_frame_sequence_number:
                            event = FopEvent(FopEvent.EventNumber.E8 if not clcw.is_wait_flag() else FopEvent.EventNumber.E9, clcw=clcw, ss=self.suspend_state)
                        else:
                            if self.transmission_count < self.transmission_limit:
                                event = FopEvent(FopEvent.EventNumber.E10 if not clcw.is_wait_flag() else FopEvent.EventNumber.E11, clcw=clcw, ss=self.suspend_state)
                            else:
                                event = FopEvent(FopEvent.EventNumber.E12 if not clcw.is_wait_flag() else FopEvent.EventNumber.E103, clcw=clcw, ss=self.suspend_state)
            else:
                event = FopEvent(FopEvent.EventNumber.E13, clcw=clcw, ss=self.suspend_state)
        else:
            event = FopEvent(FopEvent.EventNumber.E14, clcw=clcw, ss=self.suspend_state)
        self.apply_state_transition(event)


    # Perform comparison to check if num is less than otherNum mod 256, given the provided window.
    # Basically, the window tells how much other_num can be greater than num, including wrap around.
    # param num: the first term to compare
    # param other_num: the second term to compare
    # param window: the window size
    # return true if num is less than otherNum, otherwise false
    def less_than(self, num, other_num, window):
        # Expand num to window elements
        expanded_set = set((num + 1 + i) % 256 for i in range(window))
        # If other_num is within the expanded set, return True, else return False
        return other_num in expanded_set

    # Perform comparison to check if num is greater than other_num mod 256, given the provided window.
    # Basically, the window tells how much num can be greater than other_num, including wrap around.
    # param num: the first term to compare
    # param other_num: the second term to compare
    # param window: the window size
    # return true if num is greater than otherNum, otherwise false
    def greater_than(self, num, other_num, window):
        # Expand other_num to window elements
        expanded_set = set((other_num + 1 + i) % 256 for i in range(window))
        # If num is within the expanded set, return True, else return False
        return num in expanded_set

    # Determine FopEvent event when transmit timeout timer expired
    def process_timer_expired(self):
        event = None
        if self.transmission_count < self.transmission_limit:
            event = FopEvent(FopEvent.EventNumber.E16 if self.timeout_type == 0 else FopEvent.EventNumber.E104, ss=self.suspend_state)
        else:
            event = FopEvent(FopEvent.EventNumber.E17 if self.timeout_type == 0 else FopEvent.EventNumber.E18, ss=self.suspend_state)
        self.apply_state_transition(event)

    # Determine FopEvent event when request to transmit BD frame received
    def process_bd_frame(self, frame):
        event = FopEvent(FopEvent.EventNumber.E21 if self.bd_out_ready_flag else FopEvent.EventNumber.E22, frame=frame, ss=self.suspend_state)
        self.apply_state_transition(event)

    # Determine FopEvent event when request to transmit AD frame received
    def process_ad_frame(self, frame):
        event = None
        if self.wait_queue.get() is None:
            event = FopEvent(FopEvent.EventNumber.E19, frame=frame, ss=self.suspend_state)
        else:
            event = FopEvent(FopEvent.EventNumber.E20, frame=frame, ss=self.suspend_state)
        self.apply_state_transition(event)

    # Determine FopEvent event when directive received
    def process_directive(self, tag, directive, qualifier):
        event = None
        if (directive == FopDirective.INIT_AD_WITHOUT_CLCW):
            event = FopEvent(FopEvent.EventNumber.E23, directive_tag=tag, directive_id=directive, directive_qualifier=qualifier, ss=self.suspend_state)
        elif (directive == FopDirective.INIT_AD_WITH_CLCW):
            event = FopEvent(FopEvent.EventNumber.E24, directive_tag=tag, directive_id=directive, directive_qualifier=qualifier, ss=self.suspend_state)
        elif (directive == FopDirective.INIT_AD_WITH_UNLOCK):
            event = FopEvent(FopEvent.EventNumber.E25 if self.bc_out_ready_flag else FopEvent.EventNumber.E26, directive_tag=tag, directive_id=directive, directive_qualifier=qualifier, ss=self.suspend_state)
        elif (directive == FopDirective.INIT_AD_WITH_SET_V_R):
            event = FopEvent(FopEvent.EventNumber.E27 if self.bc_out_ready_flag else FopEvent.EventNumber.E28, directive_tag=tag, directive_id=directive, directive_qualifier=qualifier, ss=self.suspend_state)
        elif (directive == FopDirective.TERMINATE):
            event = FopEvent(FopEvent.EventNumber.E29, directive_tag=tag, directive_id=directive, directive_qualifier=qualifier, ss=self.suspend_state)
        elif (directive == FopDirective.RESUME):
            suspend_state_mapping = {
                0: FopEvent.EventNumber.E30,
                1: FopEvent.EventNumber.E31,
                2: FopEvent.EventNumber.E32,
                3: FopEvent.EventNumber.E33,
                4: FopEvent.EventNumber.E34
            }
            event = FopEvent(suspend_state_mapping.get(self.suspend_state, FopEvent.EventNumber.E40), directive_tag=tag, directive_id=directive, directive_qualifier=qualifier, ss=self.suspend_state)
        elif (directive == FopDirective.SET_V_S):
            event = FopEvent(FopEvent.EventNumber.E35, directive_tag=tag, directive_id=directive, directive_qualifier=qualifier, ss=self.suspend_state)
        elif (directive == FopDirective.SET_FOP_SLIDING_WINDOW):
            event = FopEvent(FopEvent.EventNumber.E36, directive_tag=tag, directive_id=directive, directive_qualifier=qualifier, ss=self.suspend_state)
        elif (directive == FopDirective.SET_T1_INITIAL):
            event = FopEvent(FopEvent.EventNumber.E37, directive_tag=tag, directive_id=directive, directive_qualifier=qualifier, ss=self.suspend_state)
        elif (directive == FopDirective.SET_TRANSMISSION_LIMIT):
            event = FopEvent(FopEvent.EventNumber.E38, directive_tag=tag, directive_id=directive, directive_qualifier=qualifier, ss=self.suspend_state)
        elif (directive == FopDirective.SET_TIMEOUT_TYPE):
            event = FopEvent(FopEvent.EventNumber.E39, directive_tag=tag, directive_id=directive, directive_qualifier=qualifier, ss=self.suspend_state)
        else:
            event = FopEvent(FopEvent.EventNumber.E40, directive_tag=tag, directive_id=directive, directive_qualifier=qualifier, ss=self.suspend_state)
        self.apply_state_transition(event)

    # Determine FopEvent event when response from lower layer received
    def process_lower_layer(self, frame, accepted):
        event = None
        frame_type_mapping = {
            TcTransferFrame.FrameType.AD: (FopEvent.EventNumber.E41, FopEvent.EventNumber.E42),
            TcTransferFrame.FrameType.BC: (FopEvent.EventNumber.E43, FopEvent.EventNumber.E44),
            TcTransferFrame.FrameType.BD: (FopEvent.EventNumber.E45, FopEvent.EventNumber.E46)
        }
        frame_type = frame.get_frame_type()
        if frame_type in frame_type_mapping:
            accepted_event, rejected_event = frame_type_mapping[frame_type]
            event = FopEvent(accepted_event if accepted else rejected_event, frame=frame, ss=self.suspend_state)
        else:
            raise ValueError("Frame type {} not supported".format(frame_type))
        self.apply_state_transition(event)

    # Generate status report
    def report_status(self, previous_state, current_state, number):
        status = FopStatus(self.expected_ack_frame_sequence_number, len(self.sent_queue), self.wait_queue.get() is not None, self.ad_out_ready_flag, self.bc_out_ready_flag, self.bd_out_ready_flag, previous_state, current_state, number)
        for observer in self.observers:
            observer.status_report(self, status)
        if number in [FopEvent.EventNumber.E22, FopEvent.EventNumber.E45, FopEvent.EventNumber.E46]:
            self.pending_event_result.set(number)
            self.pending_accept_reject_frame.notify_all()

    # Call the functions to perform actions and transit to new state based on the event
    def apply_state_transition(self, event):
        print("Event=",event.get_number())
        previous_state = self.state.get_state()
        self.state = self.state.event(event)
        current_state = self.state.get_state()
        print("state:", self.state.get_state())
        self.report_status(previous_state, current_state, event.get_number())

    # Call output to forward the frame to the lower layer and receive response from the lower layer
    def forward_to_output(self, frame):
        result = False
        if self.output is not None:
            with self.output_lock:
                result = self.output(frame)
        self.lower_layer(frame, result)

    # Process response from lower layer
    def lower_layer(self, frame, accepted):
        self.fop_executor.submit(lambda: self.process_lower_layer(frame, accepted))

    # ---------------------------------------------------------------------------------------------------------
    # Other members
    # ---------------------------------------------------------------------------------------------------------
    # Function to call when timer expires
    def timer_expired(self):
        print("TIMER EXPIRED")
        if self.current_timer is not None:
            self.process_timer_expired()

    # Store retransmit information of each transfer frame in sent_queue   
    class TransferFrameStatus:
        def __init__(self, frame):
            self.frame = frame
            self.to_be_retransmitted = False

        def set_to_be_retransmitted(self, to_be_retransmitted):
            self.to_be_retransmitted = to_be_retransmitted

        def is_to_be_retransmitted(self):
            return self.to_be_retransmitted

        def get_frame(self):
            return self.frame

