
from overall_FopState import FopState
from overall_FopEvent import FopEvent
from overall_AbstractFopState import AbstractFopState

# Define the actions required and the appropriate methods to call for FOP-1 events while in FOP-1 state S6
class S6FopState(AbstractFopState):
    def __init__(self, engine):
        super().__init__(engine)

    # Registering event handlers for different FOP events
    def register_handlers(self):
        self.event2handler = {
            FopEvent.EventNumber.E1: self.ignore,
            FopEvent.EventNumber.E2: self.ignore,
            FopEvent.EventNumber.E3: self.ignore,
            FopEvent.EventNumber.E4: self.ignore,
            FopEvent.EventNumber.E5: self.ignore,
            FopEvent.EventNumber.E6: self.ignore,
            FopEvent.EventNumber.E7: self.ignore,
            FopEvent.EventNumber.E101: self.ignore,
            FopEvent.EventNumber.E102: self.ignore,
            FopEvent.EventNumber.E8: self.ignore,
            FopEvent.EventNumber.E9: self.ignore,
            FopEvent.EventNumber.E10: self.ignore,
            FopEvent.EventNumber.E11: self.ignore,
            FopEvent.EventNumber.E12: self.ignore,
            FopEvent.EventNumber.E103: self.ignore,
            FopEvent.EventNumber.E13: self.ignore,
            FopEvent.EventNumber.E14: self.ignore,
            FopEvent.EventNumber.E15: self.ignore,
            FopEvent.EventNumber.E19: self.reject,
            FopEvent.EventNumber.E20: self.reject,
            FopEvent.EventNumber.E21: self.e21,
            FopEvent.EventNumber.E22: self.reject,
            FopEvent.EventNumber.E23: self.e23,
            FopEvent.EventNumber.E24: self.e24,
            FopEvent.EventNumber.E25: self.e25,
            FopEvent.EventNumber.E26: self.reject,
            FopEvent.EventNumber.E27: self.e27,
            FopEvent.EventNumber.E28: self.reject,
            FopEvent.EventNumber.E29: self.e29,
            FopEvent.EventNumber.E30: self.reject,
            FopEvent.EventNumber.E31: self.e31,
            FopEvent.EventNumber.E32: self.e32,
            FopEvent.EventNumber.E33: self.e33,
            FopEvent.EventNumber.E34: self.e34,
            FopEvent.EventNumber.E35: self.e35,
            FopEvent.EventNumber.E36: self.e36,
            FopEvent.EventNumber.E37: self.e37,
            FopEvent.EventNumber.E38: self.e38,
            FopEvent.EventNumber.E39: self.e39,
            FopEvent.EventNumber.E40: self.reject,
            FopEvent.EventNumber.E41: self.e41,
            FopEvent.EventNumber.E42: self.e42,
            FopEvent.EventNumber.E43: self.e43,
            FopEvent.EventNumber.E44: self.e44,
            FopEvent.EventNumber.E45: self.e45,
            FopEvent.EventNumber.E46: self.e46
        }

    # Return the current state
    def get_state(self):
        return FopState.S6

    # Handler functions for different events
    def e23(self, fop_event):
        self.engine.accept_directive(fop_event.get_directive_tag(), fop_event.get_directive_id(), fop_event.get_directive_qualifier())
        self.engine.initialise()
        self.engine.confirm_directive(fop_event.get_directive_tag(), fop_event.get_directive_id(), fop_event.get_directive_qualifier())
        from overall_S1FopState import S1FopState
        return S1FopState(self.engine)

    def e24(self, fop_event):
        self.engine.accept_directive(fop_event.get_directive_tag(), fop_event.get_directive_id(), fop_event.get_directive_qualifier())
        self.engine.register_pending_init_ad(
            fop_event.get_directive_tag(), fop_event.get_directive_id(), fop_event.get_directive_qualifier())
        self.engine.initialise()
        self.engine.restart_timer()
        from overall_S4FopState import S4FopState
        return S4FopState(self.engine)

    def e25(self, fop_event):
        self.engine.accept_directive(fop_event.get_directive_tag(), fop_event.get_directive_id(), fop_event.get_directive_qualifier())
        self.engine.register_pending_init_ad(
            fop_event.get_directive_tag(), fop_event.get_directive_id(), fop_event.get_directive_qualifier())
        self.engine.initialise()
        self.engine.transmit_type_bc_frame_unlock(fop_event.get_directive_tag())
        from overall_S5FopState import S5FopState
        return S5FopState(self.engine)

    def e27(self, fop_event):
        self.engine.accept_directive(fop_event.get_directive_tag(), fop_event.get_directive_id(), fop_event.get_directive_qualifier())
        self.engine.register_pending_init_ad(
            fop_event.get_directive_tag(), fop_event.get_directive_id(), fop_event.get_directive_qualifier())
        self.engine.initialise()
        self.engine.prepare_for_set_vr(fop_event.get_directive_qualifier())
        self.engine.transmit_type_bc_frame_set_vr(
            fop_event.get_directive_tag(), fop_event.get_directive_qualifier())
        from overall_S5FopState import S5FopState
        return S5FopState(self.engine)

    def e29(self, fop_event):
        self.engine.accept_directive(fop_event.get_directive_tag(), fop_event.get_directive_id(), fop_event.get_directive_qualifier())
        self.engine.confirm_directive(fop_event.get_directive_tag(), fop_event.get_directive_id(), fop_event.get_directive_qualifier())
        return self

    def e31(self, fop_event):
        self.engine.accept_directive(fop_event.get_directive_tag(), fop_event.get_directive_id(), fop_event.get_directive_qualifier())
        self.engine.resume()
        self.engine.confirm_directive(fop_event.get_directive_tag(), fop_event.get_directive_id(), fop_event.get_directive_qualifier())
        from overall_S1FopState import S1FopState
        return S1FopState(self.engine)

    def e32(self, fop_event):
        self.engine.accept_directive(fop_event.get_directive_tag(), fop_event.get_directive_id(), fop_event.get_directive_qualifier())
        self.engine.resume()
        self.engine.confirm_directive(fop_event.get_directive_tag(), fop_event.get_directive_id(), fop_event.get_directive_qualifier())
        from overall_S2FopState import S2FopState
        return S2FopState(self.engine)

    def e33(self, fop_event):
        self.engine.accept_directive(fop_event.get_directive_tag(), fop_event.get_directive_id(), fop_event.get_directive_qualifier())
        self.engine.resume()
        self.engine.confirm_directive(fop_event.get_directive_tag(), fop_event.get_directive_id(), fop_event.get_directive_qualifier())
        from overall_S3FopState import S3FopState
        return S3FopState(self.engine)

    def e34(self, fop_event):
        self.engine.accept_directive(fop_event.get_directive_tag(), fop_event.get_directive_id(), fop_event.get_directive_qualifier())
        self.engine.resume()
        self.engine.confirm_directive(fop_event.get_directive_tag(), fop_event.get_directive_id(), fop_event.get_directive_qualifier())
        from overall_S4FopState import S4FopState
        return S4FopState(self.engine)

    def e35(self, fop_event):
        if fop_event.get_suspend_state() == 0:
            self.engine.accept_directive(fop_event.get_directive_tag(), fop_event.get_directive_id(), fop_event.get_directive_qualifier())
            self.engine.set_vs(fop_event.get_directive_qualifier())
            self.engine.confirm_directive(fop_event.get_directive_tag(), fop_event.get_directive_id(), fop_event.get_directive_qualifier())
        else:
            self.engine.reject_directive(fop_event.get_directive_tag(), fop_event.get_directive_id(), fop_event.get_directive_qualifier())
        return self

    def e41(self, fop_event):
        self.engine.set_ad_out_ready_flag(True)
        return self

    def e43(self, fop_event):
        self.engine.set_bc_out_ready_flag(True)
        return self

