"""
1. Process TCP messages from upper layer
2. Process TM Transfer Frames to extract CLCW
3. Frame TC Segment into TC Transfer Frame
4. Run COP logic
"""

import numpy as np
from gnuradio import gr
import pmt
import struct
import math

from overall_AbstractFopState import AbstractFopState
from overall_FopAlertCode import FopAlertCode
from overall_FopDirective import FopDirective
from overall_FopEngine import FopEngine
from overall_FopEvent import FopEvent
from overall_FopOperationStatus import FopOperationStatus
from overall_FopState import FopState
from overall_FopStatus import FopStatus
from overall_IFopObserver import IFopObserver
from overall_TcTransferFrame import TcTransferFrame
from overall_Clcw import Clcw
from overall_VirtualChannelAccessMode import VirtualChannelAccessMode
from overall_TcSenderVirtualChannel import TcSenderVirtualChannel
from overall_BcFrameCollector import BcFrameCollector
from overall_TransferFrameCollector import TransferFrameCollector


class blk(gr.sync_block):  # other base classes are basic_block, decim_block, interp_block
    def __init__(self, spacecraft_id_int =80, fecf_present_bool = False, endian_big_or_little = "big", timer_initial_value=100, transmission_limit=2, timeout_type=0, fop_sliding_window=3):  # only default arguments here
        """arguments to this function show up as parameters in GRC"""
        gr.sync_block.__init__(
            self,
            name='COP Execute',   # will show up in GRC
            in_sig=None,
            out_sig=None
        )
        self.spacecraft_id = spacecraft_id_int
        self.fecf_present = fecf_present_bool # Whether frame error control field is included in TC transfer frame
        self.endian = endian_big_or_little # Endianess of tcp messages received from/sent to upper layer
        self.timer_initial_value = timer_initial_value # Timeout duration in seconds
        self.transmission_limit = transmission_limit # Maximum number of times the first Transfer Frame on the sent_queue may be transmitted
        self.timeout_type = timeout_type # Timeout type (0 or 1)
        self.fop_sliding_window = fop_sliding_window # FOP sliding window value (1 to 255)
        self.segmented = False
        # Input port to receive directives/requests from upper layer via TCP
        self.message_port_register_in(pmt.intern('tcp_in'))
        # Input port to receive TM transfer frames containing CLCWs
        self.message_port_register_in(pmt.intern('clcw_in'))
        # Output port passing transmit data TC Transfer Frames to coding layer
        self.message_port_register_out(pmt.intern('data_out'))
        # Output port passing transmit data CLCWs to physical layer
        self.message_port_register_out(pmt.intern('direct_clcw_out'))
        # Output port passing response to upper layer
        self.message_port_register_out(pmt.intern('response_out'))
        # Messages received by 'tcp_in' port will call function 'handle_tcp'
        self.set_msg_handler(pmt.intern('tcp_in'), self.handle_tcp)
        # Messages received by 'clcw_in' port will call function 'handle_clcw'
        self.set_msg_handler(pmt.intern('clcw_in'), self.handle_clcw)
        # Dictionary to store active Virtual Channels (VC), FOP engines and TC frame collectors
        self.fop_engine_dict = {}      #key = vcid, value = [virtual_channel,tc_frame_collector,fop_engine]            
 
    # Initialise TcSenderVirtualChannel
    def initialise_vc(self, vcid):
        self.vc_access_mode = VirtualChannelAccessMode.DATA
        virtual_channel = TcSenderVirtualChannel(self.spacecraft_id,vcid,self.vc_access_mode,self.fecf_present,self.segmented)
        return virtual_channel

    # Register TransferFrameCollector
    def register_tc_collector(self,vc):
        tc_frame_collector = TransferFrameCollector()
        vc.register(tc_frame_collector)
        return tc_frame_collector

    # Initialise FopEngine
    def initialise_engine(self, virtual_channel, vcid):
        next_virtual_channel_frame_counter_getter = virtual_channel.get_next_virtual_channel_frame_counter
        next_virtual_channel_frame_counter_setter = virtual_channel.set_virtual_channel_frame_counter
        bc_frame_collector = BcFrameCollector(virtual_channel)
        bc_frame_unlock_factory: Callable[[int], TcTransferFrame] = bc_frame_collector.get
        bc_frame_set_vr_factory: Callable[[int,int], TcTransferFrame] = bc_frame_collector.apply
        output: Callable[[TcTransferFrame], bool] = self.output
        fop_engine = FopEngine(vcid,  #int
                  next_virtual_channel_frame_counter_getter, #Callable[[], int]
                  next_virtual_channel_frame_counter_setter, #Callable[[int], None]
                  bc_frame_unlock_factory,
                  bc_frame_set_vr_factory,
                  output, #Callable[[TcTransferFrame], bool]
                  self.timer_initial_value,
                  self.transmission_limit,
                  self.timeout_type,
                  self.fop_sliding_window)
        # Add observer (listen for responses by fop engine and build TCP messages to send to upper layer)
        self.observer = IFopObserver(self.tcp_server, self.endian)
        fop_engine.register(self.observer)
        return fop_engine
    
    # Check if VC of a specific VCID is active, activate VC if necessary and return a list of [virtual_channel,tc_frame_collector,fop_engine] 
    def get_fop_engine(self, vcid):
        if vcid in self.fop_engine_dict:
            return self.fop_engine_dict[vcid]
        else:
            vc = self.initialise_vc(vcid)
            tc_frame_collector = self.register_tc_collector(vc)
            fop_engine = self.initialise_engine(vc, vcid)
            self.fop_engine_dict[vcid] = [vc,tc_frame_collector,fop_engine]
            return self.fop_engine_dict[vcid]

    # Output TC transfer frame 
    def output(self, tcframe):
        tctransferframe_bin = tcframe.frame
        tctransferframe = self.bin_to_int8array(tctransferframe_bin)
        self.message_port_pub(pmt.intern('data_out'), pmt.cons(pmt.PMT_NIL, pmt.init_u8vector(len(tctransferframe), tctransferframe)))
        return True
    
    # Output response
    def tcp_server(self, msg):
        tcp_msg = self.bin_to_int8array(msg)
        self.message_port_pub(pmt.intern('response_out'), pmt.cons(pmt.PMT_NIL, pmt.init_u8vector(len(tcp_msg), tcp_msg)))

    # Extract CLCW from TM transfer frame and pass to fop engine to process
    def handle_clcw(self,msg):
        self.input_items = np.array(pmt.to_python(pmt.cdr(msg)))
        tmframe_byte = bytes(self.input_items)
        is_clcw = (tmframe_byte[1] & 0x01) == 1
        if (is_clcw):
            clcw = Clcw(tmframe_byte[-4:])
            vcid = clcw.get_virtual_channel_id()
            print("clcw received:",clcw, " vcid of clcw:",vcid)
            fop_engine = self.get_fop_engine(vcid)[2]
            if (fop_engine!=None):
                fop_engine.clcw(clcw)
            else:
                print("no fop engine found")
        else: 
            print("tm frame received, no clcw")

    # Process tcp message from upper layer, initialise VC and call fop engine to process directives/requests    
    def handle_tcp(self,msg):
        self.input_items = np.array(pmt.to_python(pmt.cdr(msg)))
        print("tcp_in inputs=",self.int8array_to_int32array(self.input_items))
        self.req_type = self.toint32(self.input_items[12:16]) #[3x4:3x4+4]
        if self.endian == 'big':
            vcid = self.input_items[19]  #[4x4]
        else:
            vcid = self.input_items[16] 
        print("vcid:" ,vcid)
        self.req_tag = self.toint32(self.input_items[20:24]) #[5x4:5x4+4]
        optional_parameter = self.toint32(self.input_items[24:28])

        # Get the VC, fop engine and tc frame collector for that vcid
        dict_value = self.get_fop_engine(vcid)
        fop_engine = dict_value[2]
        virtual_channel = dict_value[0]
        tc_frame_collector = dict_value[1]

        # Call fop_engine.directive to process directive
        if 2 <= self.req_type <= 12: #ccsds directive request
            directive = self.case_1()
            print("Executing directive", directive)
            fop_engine.directive(self.req_tag, directive, optional_parameter)
        # Packet data service request (TO COMPLETE)
        elif self.req_type in (60,70): 
            if self.verify_checksum(self.input_items):
                self.case_2(virtual_channel,tc_frame_collector, fop_engine)
            else: 
                print("Wrong checksum")
                for o in fop_engine.observers:
                    o.neg_ack_msg()
        # Direct TC segment request
        elif self.req_type in (20,30): 
            if self.verify_checksum(self.input_items):
                self.case_3(virtual_channel,tc_frame_collector, fop_engine)
            else: 
                print("Wrong checksum")
                for o in fop_engine.observers:
                    o.neg_ack_msg()
        # Direct TC transfer frame request (TO COMPLETE)
        elif self.req_type == 50:    
            if self.verify_checksum(self.input_items):
                self.case_4(virtual_channel, fop_engine)
            else: 
                print("Wrong checksum")
                for o in fop_engine.observers:
                    o.neg_ack_msg()
        # Direct CLTU request (TO COMPLETE)
        elif self.req_type == 40: 
            if self.verify_checksum(self.input_items):
                self.case_5()
            else: 
                print("Wrong checksum")
                for o in fop_engine.observers:
                    o.neg_ack_msg()
        else:
            self.default_case(fop_engine)

    # Return the respective FOP directive
    def case_1(self):
        if self.req_type == 2:
            return FopDirective.INIT_AD_WITHOUT_CLCW
        elif self.req_type == 3:
            return FopDirective.INIT_AD_WITH_CLCW
        elif self.req_type == 4:
            return FopDirective.INIT_AD_WITH_UNLOCK
        elif self.req_type == 5:
            return FopDirective.INIT_AD_WITH_SET_V_R
        elif self.req_type == 6:
            return FopDirective.TERMINATE
        elif self.req_type == 7:
            return FopDirective.RESUME
        elif self.req_type == 8:
            return FopDirective.SET_V_S
        elif self.req_type == 9:
            return FopDirective.SET_FOP_SLIDING_WINDOW
        elif self.req_type == 10:
            return FopDirective.SET_T1_INITIAL
        elif self.req_type == 11:
            return FopDirective.SET_TRANSMISSION_LIMIT
        elif self.req_type == 12:
            return FopDirective.SET_TIMEOUT_TYPE
        else:
            raise ValueError("Unsupported directive value")

    # Packet data service request (TO COMPLETE)
    def case_2(self, virtual_channel,tc_frame_collector, fop_engine):
        if (self.req_type == 60): #AD
            #bypass_flag = "0"
            packet_len = self.toint32(self.input_items[24:28]) #packet length
            int8_frame = self.input_items[28:28+packet_len] #packet data
            print("in case_2: packet=",int8_frame)
            packet = self.array_to_binary(int8_frame)
            # Perform segmentation and frame into TC transfer frame(s) and store the frame(s) in tc_frame_collector
            virtual_channel.dispatch_data_internal(True,0,packet, self.req_tag, self.req_type, True) # ad_mode, map_id, data, req_tag, operation_tag, is_packet
            # Retrieve the TC transfer frames one at a time and call fop_engine.transmit to process the TC transfer frames until all are transmitted
            while (True):   
                tcframe = tc_frame_collector.retrieve_first(False) 
                if tcframe is None:
                    break
                print("retrieve +1")
                response = fop_engine.transmit(tcframe,100) #tctransferframe, timeout in ms waiting for acceptance or rejection of the request  #return return true if the request was accepted, false it is was rejected or the timeout expired

        else: #req_type == 70 #BD
            packet_len = self.toint32(self.input_items[24:28])
            int8_frame = self.input_items[28:28+packet_len] 
            print("in case_2: packet=",int8_frame)
            packet = self.array_to_binary(int8_frame)
            # Perform segmentation and frame into TC transfer frame(s) and store the frame(s) in tc_frame_collector
            virtual_channel.dispatch_data_internal(False,0,packet, self.req_tag, self.req_type, True) # ad_mode, map_id, data, req_tag, operation_tag, is_packet
            # Retrieve the TC transfer frames one at a time and call fop_engine.transmit to process the TC transfer frames until all are transmitted
            while (True):
                tcframe = tc_frame_collector.retrieve_first(False)
                if tcframe is None:
                    break
                print("in case_2: tcframe=",tcframe)
                response = fop_engine.transmit(tcframe,100) #tctransferframe, timeout in ms waiting for acceptance or rejection of the request  #return return true if the request was accepted, false it is was rejected or the timeout expired

    # Direct TC segment request         
    def case_3(self, virtual_channel,tc_frame_collector, fop_engine): 
        #version_no = "00"
        if (self.req_type == 20): #AD
            #bypass_flag = "0"
            segment_len = self.toint32(self.input_items[24:28])
            max_length = 1017 if self.fecf_present else 1019
            if (segment_len>max_length):
                print("TC Segment length cannot be greater than {max_length}")
                for o in fop_engine.observers:
                    o.neg_ack_msg()
            else:
                int8_frame = self.input_items[28:28+segment_len]
                print("TC SEGMENT TRANSFER REQUEST(AD): Segment=",int8_frame)
                segment = self.array_to_binary(int8_frame)
                # Frame into TC transfer frame(s) and store the frame(s) in tc_frame_collector
                virtual_channel.dispatch_data_internal(True,0,segment, self.req_tag, self.req_type, False) # ad_mode, map_id, data, req_tag, operation_tag, is_packet
                # Retrieve the TC transfer frames 
                tcframe = tc_frame_collector.retrieve_first(True)
                # Call fop_engine.transmit to process the TC transfer frames 
                response = fop_engine.transmit(tcframe,100) #tctransferframe, timeout in ms waiting for acceptance or rejection of the request  #return return true if the request was accepted, false it is was rejected or the timeout expired

        else: #req_type == 30 #BD
            segment_len = self.toint32(self.input_items[24:28])
            max_length = 1017 if self.fecf_present else 1019
            if (segment_len>max_length):
                print("TC Segment length cannot be greater than {max_length}")
                for o in fop_engine.observers:
                    o.neg_ack_msg()
            else:
                int8_frame = self.input_items[28:28+segment_len] 
                print("TC SEGMENT TRANSFER REQUEST(BD): Segment=",int8_frame)
                segment = self.array_to_binary(int8_frame)
                # Frame into TC transfer frame(s) and store the frame(s) in tc_frame_collector
                virtual_channel.dispatch_data_internal(False,0,segment, self.req_tag, self.req_type, False) # ad_mode, map_id, data, req_tag, operation_tag, is_packet
                # Retrieve the TC transfer frames 
                tcframe = tc_frame_collector.retrieve_first(True)
                # Call fop_engine.transmit to process the TC transfer frames 
                response = fop_engine.transmit(tcframe,100) #tctransferframe, timeout in ms waiting for acceptance or rejection of the request  #return return true if the request was accepted, false it is was rejected or the timeout expired

    # Direct TC transfer frame request (TO COMPLETE- receive and process positive/negative ack)        
    def case_4(self, virtual_channel, fop_engine):
        frame_len = self.toint32(self.input_items[24:28])
        int8_frame = self.input_items[28:28+frame_len] #[7x4:-2x4]
        print("in case_4: int_frame=",int8_frame)
        frame = self.array_to_binary(int8_frame)
        # Convert tc transfer frame from int8 array to TcTransferFrame object
        tcframe = TcTransferFrame(frame, False, self.fecf_present, req_tag=self.req_tag, operation_tag=self.req_type)  #frame, segmented, fecf_present, sec_header_length=0, sec_trailer_length=0
        seq_no = int8_frame[4]
        print("seq no=", seq_no)
        print("v(s)=",virtual_channel.get_next_virtual_channel_frame_counter())
        # Check if the frame seq no of transfer frame match with V(S), if yes then increment V(S) and output TC transfer frame
        if (seq_no == virtual_channel.get_next_virtual_channel_frame_counter()):
            virtual_channel.increment_virtual_channel_frame_counter(256)
            response = self.output(tcframe)
            for o in fop_engine.observers:
                o.transfer_notification(fop_engine, FopOperationStatus.ACCEPT_RESPONSE if response == True else FopOperationStatus.REJECT_RESPONSE, tcframe)
        else: # Wrong frame seq no 
            for o in fop_engine.observers:
                o.neg_ack_msg()

    # Direct CLTU request (TO COMPLETE- receive and process positive/negative ack)  
    def case_5(self):
        print("Case 5 is executed.")
        clcw_len = self.toint32(self.input_items[24:28])
        clcw = self.input_items[28:28+clcw_len]
        self.message_port_pub(pmt.intern('direct_clcw_out'), pmt.cons(pmt.PMT_NIL, pmt.init_u8vector(len(clcw), clcw)))

    def default_case(self, fop_engine):
        print("Default case is executed.")
        for o in fop_engine.observers:
            o.neg_ack_msg()

    # Get the data frame (Packet/Segment/Transfer frame/CLTU) in big endian from the TCP message
    def get_tc_data(self,data_len):
        if self.endian == 'big':
            return self.input_items[28:28+data_len]
        else:
            int8_array = self.input_items[28:28+math.ceil(data_len/4)*4]
            int32_array = self.int8array_to_int32array(int8_array)
            int8_array_big = []
            for value in int32_array:
                int8_array_big.extend(struct.unpack('>4B', struct.pack('>I', value)))
            if data_len%4 == 0:
                return int8_array_big
            return int8_array_big[:data_len%4-4]

    # Convert int8 array to binary 
    def array_to_binary(self,int8_array):
        binary_data = b''
        for value in int8_array:
            binary_data += struct.pack('>B', value) #unsigned int8  
        return binary_data

    # Convert binary to int8 array   
    def bin_to_int8array(self,binary_data):
        int8_array = [int(byte) for byte in binary_data] #unsigned int8
        return int8_array
        
    # Convert int8 array to int32 array 
    def int8array_to_int32array(self,int8_array):
        int32_array = [int.from_bytes(int8_array[i:i+4], self.endian, signed=True) for i in range(0, len(int8_array), 4)]
        return int32_array 

    # Convert 4 element int8 array to int32 
    def toint32(self,int8_array):
        byte_data = bytes(int8_array)  #unsigned as gnuradio int8 is unsigned
        # Convert bytes to integer
        int32_value = int.from_bytes(byte_data, byteorder=self.endian, signed=True) 
        return int32_value
    
    # Convert binary to int32 array
    def binary_to_int32array(self,byte_data):
        int32_array = []
        step = 4  # 4 bytes per 32-bit integer
        fmt = '>' if self.endian == 'big' else '<'
        for i in range(0, len(byte_data), step):
            int32_value = struct.unpack(fmt + 'i', byte_data[i:i+step])[0]
            int32_array.append(int32_value)
        return int32_array

    # Verify checksum of TCP message
    def verify_checksum(self,input_items):
        # Convert int8 array to binary
        received_packet = self.array_to_binary(input_items)
        # Split the packet data and the checksum
        packet_data = received_packet[:-8] + received_packet[-4:]
        received_checksum = received_packet[-8:-4]
        # Convert the received checksum to an unsigned 32-bit integer
        if self.endian == 'big':
            received_checksum = struct.unpack('>I', received_checksum)[0]  # '>I' for big-endian unsigned int32
        else:
            received_checksum = struct.unpack('<I', received_checksum)[0]  # '<I' for little-endian unsigned int32
        # Convert the packet data back to a list of signed 32-bit integers
        int32_packet = self.binary_to_int32array(packet_data)
        calculated_checksum = self.calculate_checksum(int32_packet)
        return calculated_checksum == received_checksum
    
    # Calculate 2s complement 32 bit checksum for the TCP message 
    def calculate_checksum(self, packet):
        # Initialize the checksum
        checksum = 0
        # Sum up all the 32-bit words in the packet
        for word in packet:
            checksum += word
        # Take the one's complement
        checksum = ~checksum
        # Add 1 to the one's complement result
        checksum += 1
        # Take the result modulo 2^32
        checksum &= 0xFFFFFFFF
        return checksum