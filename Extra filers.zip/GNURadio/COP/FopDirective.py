from enum import Enum

# Enumerate fop directives
class FopDirective(Enum):
    INIT_AD_WITHOUT_CLCW = 1
    INIT_AD_WITH_CLCW = 2
    INIT_AD_WITH_UNLOCK = 3
    INIT_AD_WITH_SET_V_R = 4
    TERMINATE = 5
    RESUME = 6
    SET_V_S = 7
    SET_FOP_SLIDING_WINDOW = 8
    SET_T1_INITIAL = 9
    SET_TRANSMISSION_LIMIT = 10
    SET_TIMEOUT_TYPE = 11
