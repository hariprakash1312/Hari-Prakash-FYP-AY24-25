import struct
import numpy as np
from overall_TcTransferFrame import TcTransferFrame

# Create a TcTransferFrame object from a valid parameters indicating the fields of TC transfer frame header and data
class TcTransferFrameBuilder:
    def __init__(self, fecf_present):
        self.fecf_present = fecf_present
        self.bypass_flag = False
        self.control_command_flag = False
        self.spacecraft_id = 0
        self.virtual_channel_id = 0
        self.frame_sequence_number = 0
        self.free_user_data_length = 0
        self.map_id = 0
        self.segmented = False
        self.sequence_flag = 0
        self.security_header = bytearray()
        self.security_trailer = bytearray()
        self.payload_units = []
        self.operation_tag = 0
        self.req_tag = 0

        self.MAX_TC_FRAME_LENGTH = 1024
        self.TC_PRIMARY_HEADER_LENGTH = 5

        # Calculate initial free user data length
        self.free_user_data_length = self.compute_max_user_data_length()

    # Calculate the max possible user data length
    def compute_max_user_data_length(self):
        return self.MAX_TC_FRAME_LENGTH - self.TC_PRIMARY_HEADER_LENGTH - (2 if self.fecf_present else 0)

    # Set bypass flag
    def set_bypass_flag(self, bypass_flag):
        self.bypass_flag = bypass_flag
        return self

    # Set control command flag
    def set_control_command_flag(self, control_command_flag):
        self.control_command_flag = control_command_flag
        return self

    # Set spacecraft id
    def set_spacecraft_id(self, spacecraft_id):
        if not (0 <= spacecraft_id <= 1023):
            raise ValueError("Spacecraft ID must be 0 <= SC ID <= 1023, actual {}".format(spacecraft_id))
        self.spacecraft_id = spacecraft_id
        return self

    # Set virtual channel id
    def set_virtual_channel_id(self, virtual_channel_id):
        if not (0 <= virtual_channel_id <= 63):
            raise ValueError("Virtual Channel ID must be 0 <= VC ID <= 63, actual {}".format(virtual_channel_id))
        self.virtual_channel_id = virtual_channel_id
        return self

    # Set frame sequence number
    def set_frame_sequence_number(self, frame_sequence_number):
        if not (0 <= frame_sequence_number <= 255):
            raise ValueError("Frame Sequence Number must be 0 <= seq. num. <= 255, actual {}".format(frame_sequence_number))
        self.frame_sequence_number = frame_sequence_number
        return self

    # Set segmented flag, sequence flag, map id
    def set_segment(self, sequence_flag, map_id):
        if not (0 <= map_id <= 63):
            raise ValueError("Map ID must be 0 <= Map ID <= 64, actual {}".format(map_id))
        if self.is_full():
            raise ValueError("TC Frame already full")
        if not self.segmented:
            self.segmented = True
            self.free_user_data_length -= 1
        self.sequence_flag = sequence_flag
        self.map_id = map_id
        return self

    # Set unlock control command (for BC unlock frame)
    def set_unlock_control_command(self):
        # CCSDS 232.0-B-3, 4.1.3.3.2
        self.add_data(bytes([0x00]))
        return self

    # Set set v(r) control command (for BC set v(r) frame)
    def set_set_vr_control_command(self, frame_sequence_number):
        if not (0 <= frame_sequence_number <= 255):
            raise ValueError("Set V(R) Sequence Number must be 0 <= V(R) <= 255, actual {}".format(frame_sequence_number))
        # CCSDS 232.0-B-3, 4.1.3.3.3
        self.add_data(bytes([0x82, 0x00, frame_sequence_number]))
        return self

    # Set security header and trailer
    def set_security(self, header, trailer):
        if header is None and trailer is None:
            return self
        if self.is_full():
            raise ValueError("TC Frame already full")
        security_data_size = (len(header) if header else 0) + (len(trailer) if trailer else 0)
        if self.free_user_data_length < security_data_size:
            raise ValueError("TC Frame cannot accommodate additional {} bytes, remaining space is {} bytes".format(security_data_size, self.free_user_data_length))
        self.security_header = header if header else bytearray()
        self.security_trailer = trailer if trailer else bytearray()
        self.free_user_data_length -= security_data_size
        return self
    
    # Set request tag
    def set_req_tag(self, req_tag):
        self.req_tag = req_tag
        return self
    
    # Set operation tag
    def set_operation_tag(self, operation_tag):
        self.operation_tag = operation_tag
        return self

    # Add user data
    def add_data(self, data):
        # Compute if you can add the requested amount
        data_to_be_written = min(self.free_user_data_length, len(data))
        not_written_data = len(data) - data_to_be_written
        if data_to_be_written > 0:
            self.payload_units.append(data[:data_to_be_written])
            self.free_user_data_length -= data_to_be_written
        return not_written_data

    # Get user data length
    def get_free_user_data_length(self):
        return self.free_user_data_length

    # Get whether user data field is full
    def is_full(self):
        return self.free_user_data_length == 0
    
    # Calculate crc16
    def get_crc16(self, data: bytes, start: int, length: int) -> int:
        crc = 0xFFFF
        for i in range(start, start + length):
            crc ^= data[i] << 8
            for _ in range(8):
                if crc & 0x8000:
                    crc = (crc << 1) ^ 0x1021
                else:
                    crc <<= 1
        return crc & 0xFFFF

    # Build and return the tc transfer frame
    def build(self):
        payload_data_length = sum(len(pu) for pu in self.payload_units)
        frame_length = self.TC_PRIMARY_HEADER_LENGTH + payload_data_length + (2 if self.fecf_present else 0) + (1 if self.segmented else 0)
        if self.security_header:
            frame_length += len(self.security_header)
        if self.security_trailer:
            frame_length += len(self.security_trailer)

        encoded_frame = bytearray()
        encoded_frame.extend(struct.pack('>H', (self.bypass_flag << 13) | (self.control_command_flag << 12) | self.spacecraft_id))
        encoded_frame.extend(struct.pack('>H', (self.virtual_channel_id << 10) | (frame_length - 1)))
        encoded_frame.append(self.frame_sequence_number)

        if self.segmented:
            to_write = (self.sequence_flag.value << 6) | self.map_id
            encoded_frame.append(to_write)

        # If security header, write it
        encoded_frame.extend(self.security_header)

        # Write the user data
        for pu in self.payload_units:
            encoded_frame.extend(pu)

        # If security trailer, write it
        encoded_frame.extend(self.security_trailer)

        # Compute and write the FECF (if present, 2 bytes)
        if self.fecf_present:
            crc = np.uint16(0)
            crc = self.get_crc16(encoded_frame, 0, len(encoded_frame) - 2)
            encoded_frame.extend(struct.pack('>H', crc))

        # Return the frame
        return TcTransferFrame(bytes(encoded_frame), lambda vc: self.segmented, self.fecf_present, len(self.security_header), len(self.security_trailer), self.req_tag, self.operation_tag)
