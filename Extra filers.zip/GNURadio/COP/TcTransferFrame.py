import struct
import enum
import copy


# This class is used to decode and manipulate a TC transfer frame, compliant to CCSDS 232.0-B-3. It includes also support
# for the security protocol, as defined by the same standard.
class TcTransferFrame:

    # The type of TC frame.
    class FrameType(enum.Enum):
        AD = 0 # Sequence-controlled: bypass flag set to 0, control command flag set to 0
        RESERVED = 1 # Reserved for future use: bypass flag set to 0, control command flag set to 1
        BD = 2 # Expedited: bypass flag set to 1, control command flag set to 0
        BC = 3 # Control command (SetVR, Unlock): bypass flag set to 1, control command flag set to 1

    # The type of control command.
    class ControlCommandType(enum.Enum):
        UNLOCK = 0 # COP-1 Unlock directive
        SET_VR = 1 # COP-1 SetV(R) directive
        RESERVED = 2 # Reserved for future use

    # The meaning of the sequence flag in case of TC segment service.
    class SequenceFlagType(enum.Enum):
        FIRST = 0 # First block
        CONTINUE = 1 # Continuation block
        LAST = 2 # Last block
        NO_SEGMENT = 3 # No segmentation
        
    # Length of the TC Frame header
    TC_PRIMARY_HEADER_LENGTH = 5
    # Maximum length of the TC Frame according to CCSDS
    MAX_TC_FRAME_LENGTH = 1024

    def __init__(self, frame, segmented, fecf_present, sec_header_length=0, sec_trailer_length=0, req_tag=0, operation_tag=0):
        self.frame = frame # The decoded transfer frame.
        self.segmented = segmented
        self.fecf_present = fecf_present # Frame error control field presence flag.
        self.security_header_length = sec_header_length
        self.security_trailer_length = sec_trailer_length
        self.req_tag = req_tag
        self.operation_tag = operation_tag

        # Check transfer frame version number
        two_octets = struct.unpack('>H', frame[:2])[0]
        tfvn = (two_octets & 0xC000) >> 14
        if tfvn != 0:
            raise ValueError(f"Transfer Frame Version Number: expected 0, actual {tfvn}")

        # Primary header fields
        self.transfer_frame_version_number = tfvn # Transfer frame version number.
        self.bypass_flag = (two_octets & 0x2000) != 0
        self.control_command_flag = (two_octets & 0x1000) != 0
        self.spacecraft_id = two_octets & 0x03FF # Spacecraft id.

        two_octets = struct.unpack('>H', frame[2:4])[0] #next 2 octets
        self.virtual_channel_id = (two_octets & 0xFC00) >> 10 # Virtual channel id.
        self.frame_length = (two_octets & 0x03FF) + 1
        self.control_command_type = None
        self.set_vr_value = None
        self.ocf_present = None

        if self.frame_length != len(frame):
            raise ValueError(f"Wrong Frame Length: expected {len(frame)}, actual {self.frame_length}")

        self.virtual_channel_frame_count = struct.unpack('B', frame[4:5])[0] #last octet # Frame count on the virtual channel, this frame belongs to.

        if self.security_header_length > 0:
            self.data_field_start = self.TC_PRIMARY_HEADER_LENGTH + (1 if self.segmented else 0) + self.security_header_length # Data field start offset from the beginning of the frame.
            self.data_field_length = self.frame_length - self.data_field_start - self.security_trailer_length - (2 if self.fecf_present else 0) # Length of the data field (i.e. excluding FECF, OCF and security fields, if present
        else:
            self.data_field_start = self.TC_PRIMARY_HEADER_LENGTH
            self.data_field_length = self.frame_length - self.data_field_start - (2 if self.fecf_present else 0)

        if self.get_frame_type() == TcTransferFrame.FrameType.BC:
            data_field_length = len(frame) - self.data_field_start - (2 if self.fecf_present else 0) - self.security_trailer_length
            if data_field_length == 1:
                self.control_command_type = TcTransferFrame.ControlCommandType.UNLOCK if frame[self.data_field_start + self.security_header_length] == 0x00 else TcTransferFrame.ControlCommandType.RESERVED
            elif data_field_length == 3:
                if frame[self.data_field_start] == 0x82 and frame[self.data_field_start + 1] == 0x00:
                    self.control_command_type = TcTransferFrame.ControlCommandType.SET_VR
                    self.set_vr_value = struct.unpack('B', frame[self.data_field_start + 2:self.data_field_start + 3])[0]
                else:
                    self.control_command_type = TcTransferFrame.ControlCommandType.RESERVED
            else:
                self.control_command_type = TcTransferFrame.ControlCommandType.RESERVED

        if self.segmented and self.get_frame_type() != TcTransferFrame.FrameType.BC:
            seg_header = frame[self.TC_PRIMARY_HEADER_LENGTH]
            self.map_id = seg_header & 0x3F
            self.sequence_flag = TcTransferFrame.SequenceFlagType((seg_header & 0xC0) >> 6)

        if self.fecf_present:
            self.valid = self.check_validity() # FECF result: valid value only if fecfPresent is true. If there is no FECF, then the frame is considered valid.
        else:
            self.valid = True

    # Check fecf
    def check_validity(self):
        crc16 = self.get_crc16(self.frame,0,self.frame_length-2)
        crc_from_frame = self.get_fecf()
        return crc16 == crc_from_frame

    # Return frame type (BC/BD/AD)
    def get_frame_type(self):
        if self.bypass_flag:
            return TcTransferFrame.FrameType.BC if self.control_command_flag else TcTransferFrame.FrameType.BD
        else:
            return TcTransferFrame.FrameType.RESERVED if self.control_command_flag else TcTransferFrame.FrameType.AD

    def is_idle_frame(self):
        return False

    # Return bypass flag
    def is_bypass_flag(self):
        return self.bypass_flag

    # Return control command flag
    def is_control_command_flag(self):
        return self.control_command_flag

    # Return control command type (unlock/set v(r))
    def get_control_command_type(self):
        return self.control_command_type

    # Return set v(r) value
    def get_set_vr_value(self):
        return self.set_vr_value

    # Return map id
    def get_map_id(self):
        return self.map_id

    # Return sequence flag (first/continue/last/no segment)
    def get_sequence_flag(self):
        return self.sequence_flag

    # Return segmented
    def is_segmented(self):
        return self.segmented

    # Return security
    def is_security_used(self):
        return self.security_header_length != 0 or self.security_trailer_length != 0

    # Return security header length
    def get_security_header_length(self):
        return self.security_header_length

    # Return security trailer length
    def get_security_trailer_length(self):
        return self.security_trailer_length

    # Return a copy of security header
    def get_security_header_copy(self):
        return copy.deepcopy(self.frame[self.TC_PRIMARY_HEADER_LENGTH + (1 if self.segmented else 0):self.TC_PRIMARY_HEADER_LENGTH + (1 if self.segmented else 0) + self.security_header_length])

    # Return a copy of security trailer
    def get_security_trailer_copy(self):
        return copy.deepcopy(self.frame[-(2 if self.fecf_present else 0) - self.security_trailer_length:-2 if self.fecf_present else None])

    # Calculate crc16 
    def get_crc16(self, frame, offset, length) -> int:
        crc = 0xFFFF
        for i in range(offset, offset + length):
            crc ^= frame[i] << 8
            for _ in range(8):
                if crc & 0x8000:
                    crc = (crc << 1) ^ 0x1021
                else:
                    crc <<= 1
        return crc & 0xFFFF

    # Return fecf
    def get_fecf(self):
        return struct.unpack('>H', self.frame[-2:])[0]

    # Return transfer frame length
    def get_length(self):
        return len(self.frame)

    # Return fecf present
    def is_fecf_present(self):
        return self.fecf_present

    # Return transfer frame version number
    def get_transfer_frame_version_number(self):
        return self.transfer_frame_version_number

    # Return spacecraft id
    def get_spacecraft_id(self):
        return self.spacecraft_id

    # Return virtual channel id
    def get_virtual_channel_id(self):
        return self.virtual_channel_id

    # Return virtual channel frame count
    def get_virtual_channel_frame_count(self):
        return self.virtual_channel_frame_count

    # Return start index of data field 
    def get_data_field_start(self):
        return self.data_field_start

    # Return valid
    def is_valid(self):
        return self.valid

    # Return idle frame
    def is_idle_frame(self):
        return False

    # Return a copy of the frame data field.
    def get_data_field_copy(self):
        return copy.deepcopy(self.frame[self.data_field_start:self.data_field_start + self.get_data_field_length()])

    # Return the length of the data field.
    def get_data_field_length(self):
        return self.data_field_length
    
    # Return request tag
    def get_req_tag(self):
        return self.req_tag
    
    # Return operation tag
    def get_operation_tag(self):
        return self.operation_tag

    def __str__(self):
        return (
            f"TcTransferFrame{{bypassFlag={self.bypass_flag}, controlCommandFlag={self.control_command_flag}, "
            f"frameLength={self.frame_length}, segmented={self.segmented}, mapId={self.map_id}, "
            f"sequenceFlag={self.sequence_flag}, controlCommandType={self.control_command_type}, "
            f"setVrValue={self.set_vr_value}, securityHeaderLength={self.security_header_length}, "
            f"securityTrailerLength={self.security_trailer_length}, fecfPresent={self.fecf_present}, "
            f"ocfPresent={self.ocf_present}, transferFrameVersionNumber={self.transfer_frame_version_number}, "
            f"spacecraftId={self.spacecraft_id}, virtualChannelId={self.virtual_channel_id}, "
            f"virtualChannelFrameCount={self.virtual_channel_frame_count}, valid={self.valid}}}"
        )
