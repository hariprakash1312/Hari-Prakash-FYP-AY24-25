from abc import ABC, abstractmethod
from overall_FopAlertCode import FopAlertCode

# Define the actions to perform and appropriate methods to call for some FOP-1 events applicable to all FOP-1 states 
class AbstractFopState(ABC):
    def __init__(self, engine):
        self.engine = engine
        self.event2handler = {
        }
        self.register_handlers()

    @abstractmethod
    # Registering event handlers for different FOP events
    def register_handlers(self):
        # Implementation for register_handlers
        pass

    # Call the handler function for a particular event
    def event(self, fop_event):
        handler = self.event2handler.get(fop_event.get_number()) # Get the handler function
        if handler:
            return handler(fop_event) # Call the handler function, which will return the next FOP state
        else:
            return self

    @abstractmethod
    # Return the current state
    def get_state(self):
        # Implementation for getState
        pass

    # Reject the fop event
    def reject(self, fop_event):
        self.engine.reject_event(fop_event)
        return self

    # Ignore the fop event
    def ignore(self, fop_event):
        return self

    # Handler functions for different events
    def e21(self, fop_event):
        self.engine.accept(fop_event.get_frame())
        self.engine.transmit_type_bd_frame(fop_event.get_frame())
        return self

    def e29(self, fop_event):
        self.engine.accept_directive(fop_event.get_directive_tag(), fop_event.get_directive_id(), fop_event.get_directive_qualifier())
        self.engine.alert(FopAlertCode.TERM)
        self.engine.confirm_directive(fop_event.get_directive_tag(), fop_event.get_directive_id(), fop_event.get_directive_qualifier())
        from overall_S6FopState import S6FopState
        return S6FopState(self.engine)

    def e36(self, fop_event):
        self.engine.accept_directive(fop_event.get_directive_tag(), fop_event.get_directive_id(), fop_event.get_directive_qualifier())
        self.engine.set_fop_sliding_window(fop_event.get_directive_qualifier())
        self.engine.confirm_directive(fop_event.get_directive_tag(), fop_event.get_directive_id(), fop_event.get_directive_qualifier())
        return self

    def e37(self, fop_event):
        self.engine.accept_directive(fop_event.get_directive_tag(), fop_event.get_directive_id(), fop_event.get_directive_qualifier())
        self.engine.set_t1_initial(fop_event.get_directive_qualifier())
        self.engine.confirm_directive(fop_event.get_directive_tag(), fop_event.get_directive_id(), fop_event.get_directive_qualifier())
        return self

    def e38(self, fop_event):
        self.engine.accept_directive(fop_event.get_directive_tag(), fop_event.get_directive_id(), fop_event.get_directive_qualifier())
        self.engine.set_transmission_limit(fop_event.get_directive_qualifier())
        self.engine.confirm_directive(fop_event.get_directive_tag(), fop_event.get_directive_id(), fop_event.get_directive_qualifier())
        return self

    def e39(self, fop_event):
        self.engine.accept_directive(fop_event.get_directive_tag(), fop_event.get_directive_id(), fop_event.get_directive_qualifier())
        self.engine.set_timeout_type(fop_event.get_directive_qualifier())
        self.engine.confirm_directive(fop_event.get_directive_tag(), fop_event.get_directive_id(), fop_event.get_directive_qualifier())
        return self

    def e42(self, fop_event):
        self.engine.alert(FopAlertCode.LLIF)
        from overall_S6FopState import S6FopState
        return S6FopState(self.engine)

    def e44(self, fop_event):
        self.engine.alert(FopAlertCode.LLIF)
        from overall_S6FopState import S6FopState
        return S6FopState(self.engine)

    def e45(self, fop_event):
        self.engine.set_bd_out_ready_flag(True)
        return self

    def e46(self, fop_event):
        self.engine.alert(FopAlertCode.LLIF)
        from overall_S6FopState import S6FopState
        return S6FopState(self.engine)


