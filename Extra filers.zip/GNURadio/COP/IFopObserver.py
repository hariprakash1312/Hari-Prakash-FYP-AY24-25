import numpy as np
import struct

from overall_FopOperationStatus import FopOperationStatus
from overall_FopDirective import FopDirective
from overall_FopAlertCode import FopAlertCode

# Pack response/acknowledgements into correct TCP/IP message and transmit via TCP/IP back to ground station 
class IFopObserver:
    def __init__(self, tcp_server, endian):
        self.tcp_server = tcp_server
        self.endian = endian

    # Pack accept/reject/positive confirm/negative confirm for transfer requests
    def transfer_notification(self, engine, status, frame):
        print(status)
        vcid = engine.virtual_channel_id
        operation_type = frame.get_operation_tag()  
        tag = frame.get_req_tag()   
        if (status == FopOperationStatus.ACCEPT_RESPONSE):
          msg = self.accept_rej_response(operation_type, vcid, tag, 0, 0)

        elif (status == FopOperationStatus.REJECT_RESPONSE):
          msg = self.accept_rej_response(operation_type, vcid, tag, 1, 0)  # Unable to get rej_info

        elif (status == FopOperationStatus.POSITIVE_CONFIRM):
          msg = self.pos_neg_confirm_response(operation_type, vcid, tag, 0)

        elif (status == FopOperationStatus.NEGATIVE_CONFIRM):
          msg = self.pos_neg_confirm_response(operation_type, vcid, tag, 1)
        self.tcp_server(msg) # Send to 'response_out' output port of COP Execute 
        print("ack msg=",self.bin_to_int32array(msg))

    # Pack accept/reject/positive confirm/negative confirm for directive requests
    def directive_notification(self, engine, status, tag, directive, qualifier):
        print(status)
        vcid = engine.virtual_channel_id
        operation_type = self.get_op_type(directive) # Get directive type
        if (status == FopOperationStatus.ACCEPT_RESPONSE):
          msg = self.accept_rej_response(operation_type, vcid, tag, 0, 0)

        elif (status == FopOperationStatus.REJECT_RESPONSE):
          msg = self.accept_rej_response(operation_type, vcid, tag, 1, 0)  # Unable to get rej_info

        elif (status == FopOperationStatus.POSITIVE_CONFIRM):
          msg = self.pos_neg_confirm_response(operation_type, vcid, tag, 0)

        elif (status == FopOperationStatus.NEGATIVE_CONFIRM):
          msg = self.pos_neg_confirm_response(operation_type, vcid, tag, 1)
        self.tcp_server(msg) # Send to 'response_out' output port of COP Execute

    # Pack alert messages
    def alert(self, engine, code):
        vcid = engine.virtual_channel_id
        alert_code = self.get_alert_code(code)
        fop_identifier = 1  # Unable to get fop_identifier
        msg = self.alert_indication_msg(fop_identifier, vcid, alert_code)
        print("alert code=",code)
        self.tcp_server(msg) # Send to 'response_out' output port of COP Execute
        print("alert msg=",self.bin_to_int32array(msg))

    # Pack suspend messages
    def suspend(self, engine):
        vcid = engine.virtual_channel_id
        fop_identifier = 1  # Unable to get fop_identifier
        msg = self.suspend_indication_msg(fop_identifier, vcid)
        self.tcp_server(msg) # Send to 'response_out' output port of COP Execute
        print("suspend msg=",self.bin_to_int32array(msg))

    def status_report(self, engine, status):
        pass

    # Convert int32 to int8 array
    def toint8(self, int32_value):
        # Convert integer to bytes
        byte_data = int32_value.to_bytes(4, self.endian, signed=True)
        # Convert bytes to list of int8
        int8_array = [np.int8(byte) for byte in byte_data]
        return int8_array
        
    # Convert int32 to bytes
    def int32tobytes(self,  int32_value):
        if self.endian == 'big':
            return struct.pack('>i', int32_value)
        else:
            return struct.pack('<i', int32_value)
        
    # Convert bytes to int32
    def bin_to_int32array(self, binary_data):
        padding_needed = len(binary_data) % 4
        if padding_needed:
            binary_data += b'\x00' * (4 - padding_needed)

        int32_array = []
        for i in range(0, len(binary_data), 4):
            if self.endian == 'big':
                int32_value = struct.unpack('>i', binary_data[i:i+4])[0]
            else:
                int32_value = struct.unpack('<i', binary_data[i:i+4])[0]
            int32_array.append(int32_value)
        return int32_array

    # Pack negative acknowledgement message
    def neg_ack_msg(self):
        msg_size = 20 # 20 bytes default value
        msg_size_array = [(msg_size >> 64) & 0xFFFFFFFF,(msg_size >> 32) & 0xFFFFFFFF,msg_size & 0xFFFFFFFF] # Split msg_size into 3 int32 values
        neg_ack = -1
        postamble = -1234567890
        msg = (                                         # Convert from int32 values to binary
           self.int32tobytes(msg_size_array[0]) +
           self.int32tobytes(msg_size_array[1]) +
           self.int32tobytes(msg_size_array[2]) +
           self.int32tobytes(neg_ack) +
           self.int32tobytes(postamble)
           )
        self.tcp_server(msg) # Send to 'response_out' output port of COP Execute 
        print("NEG_ACK_MSG")
        print("neg ack msg=",self.bin_to_int32array(msg))

    # Build tcp message for accept/reject response
    def accept_rej_response(self, operation_type, vcid, req_tag, response, rej_info):
        #response: 0 for accept, 1 for reject   rej_info: 1 for invalid parameter limits, 2 for invalid check-sum, 3 for tc modulator not reached, 4 for invalid vcid info, 5 for invalid license, 6 for encoding error
        msg_size = 36 # 36 bytes default value
        msg_size_array = [(msg_size >> 64) & 0xFFFFFFFF,(msg_size >> 32) & 0xFFFFFFFF,msg_size & 0xFFFFFFFF] # Split msg_size into 3 int32 values
        output_flow_identifier = 0 # 0 for accept/rej response
        if (self.endian == 'big'):
            response_status = np.array([0,0,rej_info,response]) # Byte 0: response Byte 1: rej_info
        else:
            response_status = np.array([response,rej_info,0,0]) # Byte 0: response Byte 1: rej_info
        postamble = -1234567890
        msg = (                                         # Convert from int32 values to binary
           self.int32tobytes(msg_size_array[0]) +
           self.int32tobytes(msg_size_array[1]) +
           self.int32tobytes(msg_size_array[2]) +
           self.int32tobytes(output_flow_identifier) +
           self.int32tobytes(operation_type) + 
           self.int32tobytes(vcid) +
           self.int32tobytes(req_tag) +
           struct.pack('b' * len(response_status), *response_status) +
           self.int32tobytes(postamble)
           )
        return msg # Return tcp msg in binary

    # Build tcp message for positive/negative confirm response
    def pos_neg_confirm_response(self, operation_type, vcid, req_tag, response): #response: 0 for positive, 1 for negative
        msg_size = 36 # 36 bytes default value
        msg_size_array = [(msg_size >> 64) & 0xFFFFFFFF,(msg_size >> 32) & 0xFFFFFFFF,msg_size & 0xFFFFFFFF] # Split msg_size into 3 int32 values
        output_flow_identifier = 1 # 1 for postive/neg confirm response
        response_status = response
        postamble = -1234567890
        msg = (                                         # Convert from int32 values to binary
           self.int32tobytes(msg_size_array[0]) +
           self.int32tobytes(msg_size_array[1]) +
           self.int32tobytes(msg_size_array[2]) +
           self.int32tobytes(output_flow_identifier) +
           self.int32tobytes(operation_type) + 
           self.int32tobytes(vcid) +
           self.int32tobytes(req_tag) +
           self.int32tobytes(response_status) +
           self.int32tobytes(postamble)
           )
        return msg # Return tcp msg in binary

    # Build tcp message for alert indication message
    def alert_indication_msg(self, fop_identifier, vcid, alert_code):
        msg_size = 32 # 32 bytes default value
        msg_size_array = [(msg_size >> 64) & 0xFFFFFFFF,(msg_size >> 32) & 0xFFFFFFFF,msg_size & 0xFFFFFFFF] # Split msg_size into 3 int32 values
        output_flow_identifier = 2 # 2 for alert indication message
        postamble = -1234567890
        msg = (                                         # Convert from int32 values to binary
           self.int32tobytes(msg_size_array[0]) +
           self.int32tobytes(msg_size_array[1]) +
           self.int32tobytes(msg_size_array[2]) +
           self.int32tobytes(output_flow_identifier) +
           self.int32tobytes(fop_identifier) + 
           self.int32tobytes(vcid) +
           self.int32tobytes(alert_code) +
           self.int32tobytes(postamble)
           )
        return msg # Return tcp msg in binary

    # Build tcp message for suspend indication message
    def suspend_indication_msg(self, fop_identifier, vcid):
        msg_size = 32 # 32 bytes default value
        msg_size_array = [(msg_size >> 64) & 0xFFFFFFFF,(msg_size >> 32) & 0xFFFFFFFF,msg_size & 0xFFFFFFFF] # Split msg_size into 3 int32 values
        output_flow_identifier = 3 # 2 for suspend indication message
        suspend_indication = 0 # default value
        postamble = -1234567890
        msg = (                                         # Convert from int32 values to binary
           self.int32tobytes(msg_size_array[0]) +
           self.int32tobytes(msg_size_array[1]) +
           self.int32tobytes(msg_size_array[2]) +
           self.int32tobytes(output_flow_identifier) +
           self.int32tobytes(fop_identifier) + 
           self.int32tobytes(vcid) +
           self.int32tobytes(suspend_indication) +
           self.int32tobytes(postamble)
           )
        return msg # Return tcp msg in binary

    # Get the operation type field value for the respective directives
    def get_op_type(self, directive):
        if (directive == FopDirective.INIT_AD_WITHOUT_CLCW):
            return 2
        elif (directive == FopDirective.INIT_AD_WITH_CLCW):
            return 3
        elif (directive == FopDirective.INIT_AD_WITH_UNLOCK):
            return 4
        elif (directive == FopDirective.INIT_AD_WITH_SET_V_R):
            return 5
        elif (directive == FopDirective.TERMINATE):
            return 6
        elif (directive == FopDirective.RESUME):
            return 7
        elif (directive == FopDirective.SET_V_S):
            return 8
        elif (directive == FopDirective.SET_FOP_SLIDING_WINDOW):
            return 9
        elif (directive == FopDirective.SET_T1_INITIAL):
            return 10
        elif (directive == FopDirective.SET_TRANSMISSION_LIMIT):
            return 11
        elif (directive == FopDirective.SET_TIMEOUT_TYPE):
            return 12

    # Get the alert code field value for the respective alert codes
    def get_alert_code(self, code):
        if code == FopAlertCode.LIMIT:
            return 1
        elif code == FopAlertCode.LOCKOUT:
            return 2
        elif code == FopAlertCode.SYNCH:
            return 3
        elif code == FopAlertCode.NN_R:
            return 4
        elif code == FopAlertCode.CLCW:
            return 5
        elif code == FopAlertCode.LLIF:
            return 6
        elif code == FopAlertCode.TERM:
            return 7
        elif code == FopAlertCode.T1:
            return 9
        else:
            return 8 #alert not applicable
            
            
    
