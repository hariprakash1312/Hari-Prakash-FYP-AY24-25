# Encapsulate fop status information
class FopStatus:
    def __init__(self, expected_ack_frame_sequence_number, sent_queue_items, wait_queue_full, ad_out_ready_flag, bc_out_ready_flag, bd_out_ready_flag, previous_state, current_state, event):
        self.expected_ack_frame_sequence_number = expected_ack_frame_sequence_number
        self.sent_queue_items = sent_queue_items
        self.wait_queue_full = wait_queue_full
        self.ad_out_ready_flag = ad_out_ready_flag
        self.bc_out_ready_flag = bc_out_ready_flag
        self.bd_out_ready_flag = bd_out_ready_flag
        self.previous_state = previous_state
        self.current_state = current_state
        self.event = event

    def get_expected_ack_frame_sequence_number(self):
        return self.expected_ack_frame_sequence_number

    def get_sent_queue_items(self):
        return self.sent_queue_items

    def is_wait_queue_full(self):
        return self.wait_queue_full

    def is_ad_out_ready_flag(self):
        return self.ad_out_ready_flag

    def is_bc_out_ready_flag(self):
        return self.bc_out_ready_flag

    def is_bd_out_ready_flag(self):
        return self.bd_out_ready_flag

    def get_previous_state(self):
        return self.previous_state

    def get_current_state(self):
        return self.current_state

    def get_event(self):
        return self.event

    def __str__(self):
        return f"FopStatus{{NN(R)={self.get_expected_ack_frame_sequence_number()}, " \
               f"previousState={self.get_previous_state()}, currentState={self.get_current_state()}, " \
               f"event={self.get_event()}, sentQueueItems={self.get_sent_queue_items()}, " \
               f"waitQueueFull={self.is_wait_queue_full()}, adOutReadyFlag={self.is_ad_out_ready_flag()}, " \
               f"bcOutReadyFlag={self.is_bc_out_ready_flag()}, bdOutReadyFlag={self.is_bd_out_ready_flag()}}}"
