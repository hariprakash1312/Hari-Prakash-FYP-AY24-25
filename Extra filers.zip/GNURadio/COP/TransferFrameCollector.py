from overall_TcTransferFrame import TcTransferFrame

# Store AD and BD frames, where the TcSenderVirtualChannel will put in AD/BD frames created and Cop Execute will retrieve the frames
class TransferFrameCollector:
    def __init__(self):
        self.frame_list = []

    # Return and remove first frame from frame_list (if exists), clear list if clear_list = True
    def retrieve_first(self, clear_list=True):
        first_frame = self.frame_list.pop(0) if self.frame_list else None
        if clear_list:
            self.frame_list.clear()
        return first_frame

    # Return a copy of the current frame_list and clears frame_list
    def retrieve(self):
        copied_list = self.frame_list.copy()
        self.frame_list.clear()
        return copied_list

    # Add generated_frame to frame_list if it is a AD/BD frame
    def transfer_frame_generated(self, virtual_channel, generated_frame, buffered_bytes):
        if generated_frame.get_frame_type() == TcTransferFrame.FrameType.AD or generated_frame.get_frame_type() == TcTransferFrame.FrameType.BD:
            self.frame_list.append(generated_frame)
