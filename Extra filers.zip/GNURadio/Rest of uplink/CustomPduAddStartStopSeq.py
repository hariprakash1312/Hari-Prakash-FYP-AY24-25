"""
Add Start and Tail sequence to frame into a CLCW 
"""

import numpy as np
from gnuradio import gr
import pmt

class blk(gr.basic_block):  # other base classes are basic_block, decim_block, interp_block
    def __init__(self):  # only default arguments here
        """arguments to this function show up as parameters in GRC"""
        gr.basic_block.__init__(
            self,
            name='Custom PDU Add Start/Stop Seq',   # will show up in GRC
            in_sig=None,
            out_sig=None
        )
        # Register input message passing port 
        self.message_port_register_in(pmt.intern('msg_in'))
        # Register output message passing port
        self.message_port_register_out(pmt.intern('msg_out'))
        # Register message handler for input port 'msg_in', ie specify function to call when a message is received on input port 
        self.set_msg_handler(pmt.intern('msg_in'), self.handle_msg)

    # Add the start_seq and stop_seq to the start and end of the packet respectively
    def handle_msg(self, msg): 
        start_seq = np.array([int("11101011",2),int("10010000",2)])
        stop_seq = np.array([int("C5",16),int("C5",16),int("C5",16),int("C5",16),int("C5",16),int("C5",16),int("C5",16),int("79",16)])
        data = np.concatenate((start_seq, np.array(pmt.to_python(pmt.cdr(msg))),stop_seq))
        self.message_port_pub(pmt.intern('msg_out'), pmt.cons(pmt.PMT_NIL, pmt.init_u8vector(len(data), data)))