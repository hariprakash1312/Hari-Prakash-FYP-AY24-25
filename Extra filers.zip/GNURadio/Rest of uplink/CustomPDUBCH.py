"""
(64,56) modified BCH Encoding, polynomial h(x) = x7 + x6 + x2 + 1
"""

import numpy as np
from gnuradio import gr
import pmt

class blk(gr.basic_block):  # other base classes are basic_block, decim_block, interp_block
    # Total no of bytes in BCH Codeblock  
    n = 8
    # No of data bytes in BCH Codeblock
    k = 7
    a = -1
    
    def __init__(self):  # only default arguments here
        """arguments to this function show up as parameters in GRC"""
        gr.basic_block.__init__(
            self,
            name='Custom PDU BCH',   # will show up in GRC
            in_sig=None,
            out_sig=None
        )
        # Register input message passing port 
        self.message_port_register_in(pmt.intern('msg_in'))
        # Register output message passing port
        self.message_port_register_out(pmt.intern('msg_out'))
        # Register message handler for input port 'msg_in', ie specify function to call when a message is received on input port 
        self.set_msg_handler(pmt.intern('msg_in'), self.handle_msg)  
        
    # Get the number of bch blks, calculate the bch parity and concatenate to each blk
    def handle_msg(self, msg):  
        input_items = np.array(pmt.to_python(pmt.cdr(msg)))
        blks = int((len(input_items)/self.k)) # No of BCH blocks in transfer frame
        
        in56 = [None]*self.k # 7 element array for storing data bytes of BCH block
        out64 = [None]*self.n # 8 element array for storing BCH block
        output_items = [None]*(blks*self.n) # output array

        if (blks < 1):
            if (self.a == -1):
                print("Error: not enough input data")
                self.a = 0
            return 0
        # Calculate and fill parity bits for each BCH codeblock
        for i in range(blks):
            for j in range(self.k):
                in56[j] = input_items[j+i*self.k]
            out64 = self.bch(in56)
            for j in range(self.n):
                output_items[j+i*self.n] = out64[j]
        self.message_port_pub(pmt.intern('msg_out'), pmt.cons(pmt.PMT_NIL, pmt.init_u8vector(len(output_items), output_items)))
         
    # BCH error encoding
    def bch(self, in56):
        # Initialize the output array with None values
        out64 = [None] * self.n
        message = ""  # Initialize an empty string to store the binary representation of the input bytes

        # Loop over the first 8 bytes of the input
        for i in range(self.n):
            if i < self.k:
                # Process the first 7 bytes
                byte = in56[i]
                out64[i] = byte  # Store the byte in the output array
                message += format(byte & 0xFF, '08b')  # Convert byte to an 8-bit binary string and append to message
            if i == self.k:
                # Process the 8th byte (parity calculation)
                out_parity = ""  # Initialize an empty string for the parity bits
                x0 = x1 = x2 = x3 = x4 = x5 = x6 = 0  # Initialize shift register bits to 0
                parity = x6 ^ 1  # Initial parity value, inverted x6

                # Loop over 64 bits to calculate parity
                for j in range(64):
                    if j < 56:
                        # Process the first 56 bits of the message
                        bitin = int(message[j])  # Get the j-th bit from the message
                        bitin2 = x6 ^ bitin  # XOR the bit with x6
                    if 56 <= j < 63:
                        # Process bits 56 to 62 (parity bits)
                        out_parity += str(parity)  # Append the current parity bit to out_parity
                        bitin2 = 0  # No input bit for these positions
                    if j == 63:
                        # Process the 63rd bit (final parity bit)
                        out_parity += "0"  # Append a 0 to out_parity
                        bitin2 = 0  # No input bit for this position

                    # Update the shift register bits with XOR logic
                    x6 = x5 ^ bitin2
                    x5 = x4
                    x4 = x3
                    x3 = x2
                    x2 = x1 ^ bitin2
                    x1 = x0
                    x0 = bitin2

                    # Update parity with the inverted x6
                    parity = x6 ^ 1

                # Convert the parity bits from binary string to integer and store in the output array
                out64[i] = int(out_parity, 2)

        # Return the final 64-byte output array
        return out64
