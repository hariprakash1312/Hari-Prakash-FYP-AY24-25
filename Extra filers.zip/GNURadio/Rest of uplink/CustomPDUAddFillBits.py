"""
Add fill bits at the end of the transfer frame to fill up 7 bytes for the last BCH codeblock
"""

import numpy as np
from gnuradio import gr
import pmt

class blk(gr.basic_block):  # other base classes are basic_block, decim_block, interp_bloc
    # No of data bytes for 1 BCH codeblock
    k = 7
    def __init__(self):  
        """arguments to this function show up as parameters in GRC"""
        gr.basic_block.__init__(
            self,
            name='Custom PDU Add Fill Bits',   # will show up in GRC
            in_sig=None,
            out_sig=None
        )
        # Register input message passing port 
        self.message_port_register_in(pmt.intern('msg_in'))
        # Register output message passing port
        self.message_port_register_out(pmt.intern('msg_out'))
        # Register message handler for input port 'msg_in', ie specify function to call when a message is received on input port 
        self.set_msg_handler(pmt.intern('msg_in'), self.handle_msg)

    # If the length of the transfer frame is not a multiple of 7, add fill bytes until the length is a multiple of 7
    def handle_msg(self, msg): 
        # Convert input message ie pdu to array of bytes
        input_items = np.array(pmt.to_python(pmt.cdr(msg)))
        # Compute no of bytes of fill bits required
        rem = len(input_items)%self.k
        # Store fill bits required in byte array 'add_items' and concatenate to input byte array 'input_items'
        if (rem != 0):
            add_items = [None]*(self.k-rem)
            for j in range(self.k-rem):
                add_items[j] = 85 #85 is the decimal representation of '01010101', which are the fill bits
            output_items = np.concatenate((input_items, np.array(add_items)))
        else:
            output_items = input_items
        # Output byte array 'output_items' to port 'msg_out' as a PDU
        self.message_port_pub(pmt.intern('msg_out'), pmt.cons(pmt.PMT_NIL, pmt.init_u8vector(len(output_items), output_items)))
    

        
