"""
Bit randomiser using 255-bit randomisation sequence generated using polynomial h(x) = x8 + x6 + x4 + x3 + x2 + x + 1
"""

import numpy as np
from gnuradio import gr
import pmt

class blk(gr.basic_block):  # other base classes are basic_block, decim_block, interp_block
    # Initialise shift registers to "all ones" state
    x1 = x2 = x3 = x4 = x5 = x6 = x7 = x8 = 1  
    
    def __init__(self):  
        """arguments to this function show up as parameters in GRC"""
        gr.basic_block.__init__(
            self,
            name='Custom PDU Randomiser',   # will show up in GRC
            in_sig=None,
            out_sig=None
        )
        # Register input message passing port 
        self.message_port_register_in(pmt.intern('msg_in'))
        # Register output message passing port
        self.message_port_register_out(pmt.intern('msg_out'))
        # Register message handler for input port 'msg_in', ie specify function to call when a message is received on input port 
        self.set_msg_handler(pmt.intern('msg_in'), self.handle_msg)
        
                
    def handle_msg(self, msg):
        # Convert input message ie pdu to array of bytes
        input_items = np.array(pmt.to_python(pmt.cdr(msg)))
        output_items = [None]*len(input_items)
        # Iterate over each input byte, calculate the randomised output 
        for i in range(len(input_items)):  
            output_items[i] = self.btg(input_items[i])
        # Output randomised data to port 'msg_out' as a PDU(protocol data unit), which is defined as a PMT pair using pmt.cons(KEY,VALUE)
        # where KEY= empty and VALUE= pmt vector of bytes 
        self.message_port_pub(pmt.intern('msg_out'), pmt.cons(pmt.PMT_NIL, pmt.init_u8vector(len(output_items), output_items)))
        # Reset shift registers
        self.btg_reset()
    
    """
    Bit transition generator using a shift register with feedback.
    Args:
        in_data (int): 8-bit input data to be transformed.
    Returns:
        int: Transformed 8-bit output data.
    """  
    def btg(self, in_data): 
        out_byte = ""  # Initialize the output byte as an empty string
        message = format(in_data & 0xFF, '08b')  # Convert input data to an 8-bit binary string 
        for i in range(8):  # Iterate over each bit in the input data
            # XOR the first register bit with the current message bit and add to output byte
            out_byte += str(self.x1 ^ int(message[i]))
            # Calculate the new feedback value using XOR operations
            xor1 = self.x1 ^ self.x2
            xor2 = xor1 ^ self.x3
            xor3 = xor2 ^ self.x4
            xor4 = xor3 ^ self.x5
            xor5 = xor4 ^ self.x7
            # Shift the register values
            self.x1 = self.x2
            self.x2 = self.x3
            self.x3 = self.x4
            self.x4 = self.x5
            self.x5 = self.x6
            self.x6 = self.x7
            self.x7 = self.x8
            self.x8 = xor5  # Update the last register value with the final XOR result
        out_data = int(out_byte, 2)  # Convert the output byte string back to an integer
        return out_data  # Return the transformed output data

    def btg_reset(self):
        self.x1 = self.x2 = self.x3 = self.x4 = self.x5 = self.x6 = self.x7 = self.x8 = 1

