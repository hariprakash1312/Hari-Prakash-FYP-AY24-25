"""
Add a tag to the first data sample of the tm transfer frame, with the packet length value attached 
for the next block 'Tagged Stream to PDU' to recognise the boundaries of the tm transfer frame and pack into a PDU
"""

import numpy as np
from gnuradio import gr
import pmt
 
class blk(gr.basic_block):

    def __init__(self):
        gr.basic_block.__init__(
            self,
            name='Custom Tag Stream',
            in_sig=[np.int8],
            out_sig=[np.int8]
        )
        
    # Forecast a larger no of output than actual so that the entire data packet will be read together. 
    # 1) During runtime, the scheduler asks forecast what input buffer size is needed to produce the largest amount of output that the output buffer can deal with (32768) 
    # 2) Scheduler checks if the input buffer has enough samples, if yes then that amount of output buffer is provided to general_work 
    # if no then it halves the output buffer size (16384) and repeat step 1 & 2 until it hits the minimum output buffer size (1)
    # e.g. if packet is 223 bytes, output buffer size provided is 256 (as input buffer required (256/2 =128) is greater than actual input buffer (223))
    def forecast(self, noutput_items, ninputs):
        ninput_items_required = [0] * ninputs
        if (noutput_items-2 -1 <0):
            ninput_items_required[0] = int(noutput_items)
        else:
            ninput_items_required[0] = int(noutput_items/2)
        return ninput_items_required    
 
    # Add a tag to the first data sample of packet with key = name of tag and value = length of packet
    def general_work(self, input_items, output_items):
        in_length = len(input_items[0])
        key = pmt.intern("packet_len")
        value = pmt.from_long(in_length)
        self.add_item_tag(0, # Write to output port 0
                 self.nitems_written(0), # Index of the tag in absolute terms
                 key, # Key of the tag
                 value # Value of the tag
        )
        print("length:",in_length)
        
        for i in range(0,len(input_items[0]),1):
            output_items[0][i] = input_items[0][i]
        self.consume(0,len(input_items[0]))
        return len(input_items[0])