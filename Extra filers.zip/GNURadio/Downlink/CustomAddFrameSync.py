"""
Add Frame Sync (1ACFFC1D, from CCSDS Telemetry Channel Coding 5-2) to the RS encoded TM transfer frame 
"""

import numpy as np
from gnuradio import gr
import pmt

class blk(gr.sync_block):  # other base classes are basic_block, decim_block, interp_block
    def __init__(self):  # only default arguments here
        """arguments to this function show up as parameters in GRC"""
        gr.sync_block.__init__(
            self,
            name='Custom Add Frame Sync',   # will show up in GRC
            in_sig=None,
            out_sig=None
        )
        self.message_port_register_in(pmt.intern('msg_in'))
        self.message_port_register_out(pmt.intern('msg_out'))
        self.set_msg_handler(pmt.intern('msg_in'), self.handle_msg)
        
    def handle_msg(self, msg):
        data = np.concatenate((np.array([int("00011010",2),int("11001111",2),int("11111100",2),int("00011101",2)]), np.array(pmt.to_python(pmt.cdr(msg)))))
        self.message_port_pub(pmt.intern('msg_out'), pmt.cons(pmt.PMT_NIL, pmt.init_u8vector(len(data), data)))

     

    