"""
Perform symbol inversion for the output path of the 2nd polynomial (1011011 or 133 octal) of the convolutional encoder
i.e. invert the 2nd,4th,6th,... bits (bit 1,3,5,...)
"""

from gnuradio import gr
import pmt

class blk(gr.sync_block):  # other base classes are basic_block, decim_block, interp_block
    def __init__(self):  # only default arguments here
        """arguments to this function show up as parameters in GRC"""
        gr.sync_block.__init__(
            self,
            name='Custom invert',   # will show up in GRC
            in_sig = None,
            out_sig = None
        )
        self.message_port_register_in(pmt.intern('msg_in'))
        self.message_port_register_out(pmt.intern('msg_out'))
        self.set_msg_handler(pmt.intern('msg_in'), self.handle_msg)

    def handle_msg(self, msg):
        data = pmt.to_python(pmt.cdr(msg))
        # Perform XOR operation on the odd indexes (bit 1,3,5,...)
        output_data = [byte ^ 1 if i % 2 == 1 else byte for i, byte in enumerate(data)]
        self.message_port_pub(pmt.intern('msg_out'), pmt.cons(pmt.PMT_NIL, pmt.init_u8vector(len(output_data), output_data)))
       


  