import socket
import os 

# TCP Client that connects to port 2002, acts as the downlink sending TM Transfer Frames containing CLCWs to COP Execute block in GNURadio
# Enter name of file eg fop_test_clcw.txt in the folder COP_Requests in the console to send contents of file to TCP Server (i.e. GNURadio)
# Make sure TCP Server (i.e. GNURadio) is running before running this code


def send_input(client_socket,testinterfaceinput):
    try: 
        data = testinterfaceinput
        client_socket.sendall(data)
    except Exception as e:
        print("No input detected", e)

# Set up the TCP client
server_ip = '127.0.0.1'  # Server IP address
server_port = 52001  # Server port
client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

try:
    client_socket.connect((server_ip, server_port))
    print(f"Connected to server {server_ip}:{server_port}")
    testinteger=int(input("Test prompt: "))
    testinterfaceinput = testinteger.to_bytes((testinteger.bit_length() + 7) // 8, byteorder='big')
    send_input(client_socket, testinterfaceinput)
    #search how to concatenate 2 bytes(first btyte control , 2nd byte data)
    #1st byte (00000000->change sample rate control , 0001-> Change Endianess control)    

except ConnectionRefusedError:
    print("Connection refused. Make sure the server is running.")
finally:
    client_socket.close()


# edit according to psuedocode 
# codes to include first 