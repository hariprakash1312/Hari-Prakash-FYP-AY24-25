import os

def create_tm_frame(useful_file_path, dummy_file_path, output_file_path):
    try:
        # Read the useful data
        with open(useful_file_path, 'rb') as useful_file:
            useful_data = useful_file.read()

        # Read the dummy data
        with open(dummy_file_path, 'rb') as dummy_file:
            dummy_data = dummy_file.read()

        # Create the new data format: 10*dummy data + useful data + 10*dummy data
        new_data = (dummy_data * 10) + useful_data + (dummy_data * 10)

        # Write the new data to the output file
        with open(output_file_path, 'wb') as output_file:
            output_file.write(new_data)

        print(f"Successfully created TM frame and saved to {output_file_path}")

    except FileNotFoundError as e:
        print(f"Error: {e}")
    except Exception as e:
        print(f"An error occurred: {e}")

if __name__ == "__main__":
    # Example paths (replace with actual paths or take as input)
    useful_file_path = r"C:\Users\harip\OneDrive\Desktop\Fyp\Low Ai Ning FYP\Codes\telemetryout_test.txt"
    dummy_file_path = r"C:\Users\harip\OneDrive\Desktop\Fyp\Low Ai Ning FYP\Codes\telemetryout_testdummy.txt"
    output_file_path = r"C:\Users\harip\OneDrive\Desktop\28 sep\test1.txt"

    create_tm_frame(useful_file_path, dummy_file_path, output_file_path)


