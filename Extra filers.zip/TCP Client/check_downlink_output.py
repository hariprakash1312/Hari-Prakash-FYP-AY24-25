import os

# Compare the contents of 'fop_test_clcw.txt' and the first 223 bytes of 'telemetryreceived.txt' to check if the contents sent 
# 'fop_test_clcw.txt' and the contents received 'telemetryreceived.txt' are the same 
# Replace 'fop_test_clcw.txt' if the data sent is from another file
current_directory = os.path.dirname(os.path.abspath(__file__))
send_file = os.path.join(current_directory, "..", "COP_Requests", "fop_test_clcw.txt")

with open(send_file, 'rb') as binary_file:
    data = binary_file.read()
    hex_original = ''.join(f'{byte:02X}' for byte in data)
    print("original data=", hex_original)

received_file = os.path.join(current_directory, "..", "telemetryreceived.txt")
with open(received_file, 'rb') as binary_file:
    data = binary_file.read(223)
    hex_new = ''.join(f'{byte:02X}' for byte in data)
    print("received data=", hex_new)

if (hex_original == hex_new):
    print("original message = received message")