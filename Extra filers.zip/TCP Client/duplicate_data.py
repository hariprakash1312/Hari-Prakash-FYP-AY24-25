import os 

# Read data from a file 'telemetryout_test.txt', duplicate the data 20 times and save to another file 'duplicated.txt'
def duplicate_file(file_path,output_file_path):
    with open(file_path, 'rb') as file:
        data = file.read()
    duplicated_data = data *1300

    with open(output_file_path, 'wb') as output_file:
        output_file.write(duplicated_data)

current_directory = os.path.dirname(os.path.abspath(__file__))
main_directory = os.path.join(current_directory, "..")

file_path = os.path.join(main_directory, "27oct.txt")
output_file_path = os.path.join(main_directory, "bigdatatest.txt")
duplicate_file(file_path, output_file_path)


