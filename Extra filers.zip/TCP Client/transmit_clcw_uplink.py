import socket
import os 

# TCP Client that connects to port 2002, acts as the downlink sending TM Transfer Frames containing CLCWs to COP Execute block in GNURadio
# Enter name of file eg fop_test_clcw.txt in the folder COP_Requests in the console to send contents of file to TCP Server (i.e. GNURadio)
# Make sure TCP Server (i.e. GNURadio) is running before running this code

def send_file(client_socket, file_path):
    try: 
        with open(file_path, 'rb') as file:
            while True:
                data = file.read()
                if not data:
                    break
                client_socket.sendall(data)
    except FileNotFoundError:
        print(file_path)
        print("File not found.")
    except Exception as e:
        print("Error sending file:", e)

# Set up the TCP client
server_ip = '127.0.0.1'  # Server IP address
server_port = 2002  # Server port
client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
current_directory = os.path.dirname(os.path.abspath(__file__))
cop_req_directory = os.path.join(current_directory, "..", "COP_Requests")

try:
    client_socket.connect((server_ip, server_port))
    print(f"Connected to server {server_ip}:{server_port}")

    while(True):
        # Input file path from the user
        file = input("Enter the file path to send: ")
        file_path = os.path.join(cop_req_directory, file)
        # Send file from main thread
        send_file(client_socket, file_path)

except ConnectionRefusedError:
    print("Connection refused. Make sure the server is running.")
finally:
    client_socket.close()
