import socket
import os

# TCP Client that connects to port 3070, acts as the upper layer receiving TM Transfer Frames from downlink blocks in GNURadio
# It will save the TCP messages received in a binary file 'telemetryreceived.txt' in the Codes folder
# It will print the contents of TCP messages received from TCP Server as well as the count of data received
# Make sure TCP Server (i.e. GNURadio) is running before running this code

def receive_data_from_server(save_file_path, server_address, server_port):
    # Create a TCP socket for the client
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as client_socket:
        try:
            # Connect to the server
            client_socket.connect((server_address, server_port))
            print(f"Connected to {server_address}:{server_port}")
            received_data_count = 0  # Initialize counter 
            with open(save_file_path, 'wb') as save_file:
                # Receive data from the server and save it to the file
                while True:
                    data = client_socket.recv(1024)  # Receive data from the server (1024 bytes at a time)
                    if not data:
                        break  # Connection closed by server or end of data

                    save_file.write(data)  # Write received data to the file
                    received_data_count += 1          
                    print(data)
                    print(received_data_count)


                print("File received and saved successfully.")
                print(f"Number of TCP/IP transfers received: {received_data_count}")

        except Exception as e:
            print(f"Error: {e}")

current_directory = os.path.dirname(os.path.abspath(__file__))
save_file_path = os.path.join(current_directory, "..", "10novbdt.txt")
server_address = "127.0.0.1"  # Server running on the same computer
server_port = 3070  

receive_data_from_server(save_file_path, server_address, server_port)
